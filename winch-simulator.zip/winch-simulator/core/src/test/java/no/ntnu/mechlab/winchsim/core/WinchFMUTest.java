package no.ntnu.mechlab.winchsim.core;

import no.ntnu.mechlab.winchsim.util.FMULocations;
import org.javafmi.modeldescription.ScalarVariable;
import org.javafmi.wrapper.Simulation;
import org.junit.Assert;
import org.junit.Test;

public class WinchFMUTest {

    private static void setInput(Simulation simulation) {
        for (ScalarVariable variable : simulation.getModelDescription().getModelVariables()) {

            if (variable.getCausality().equals("input")) {
                simulation.write(variable.getName()).with(0.1);
            }
        }
    }

    @Test
    public void testOutputChanges() {

        Simulation simulation;

        simulation = new Simulation(FMULocations.WINCH_FMU_PATH);

        String variableName = simulation.getModelDescription().getModelVariables()[0].getName();

        setInput(simulation);
        simulation.init(0);

        simulation.doStep(0.1);
        double x0 = simulation.read(variableName).asDouble();

        simulation = new Simulation(FMULocations.WINCH_FMU_PATH);
        setInput(simulation);
        simulation.init(0);

        simulation.doStep(0.1);
        double x1 = simulation.read(variableName).asDouble();

        simulation.doStep(0.1);
        double x2 = simulation.read(variableName).asDouble();

        Assert.assertTrue(x0 == x1);
        Assert.assertTrue(x1 != x2);
    }
}
