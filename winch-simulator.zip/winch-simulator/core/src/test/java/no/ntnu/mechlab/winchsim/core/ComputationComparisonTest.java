package no.ntnu.mechlab.winchsim.core;

import java.util.Map;
import no.ntnu.mechlab.winchsim.util.FMULocations;
import no.ntnu.mechlab.winchsim.util.VariableObtainer;
import org.javafmi.wrapper.Simulation;
import org.javafmi.wrapper.Simulation.WriteCall;
import org.javafmi.wrapper.variables.SingleRead;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Compares FMUs
 *
 * @author birger
 */
public class ComputationComparisonTest {

    private static final double DURATION = 10;
    private static final int FREQUENCY = 10000;
    private static final double MAX_ERROR = 1 / 500.0;
    private static final double MAX_TIME_ERROR = 1 / 1000000.0;
    private static final int SAMPLES = 1000;

    private final FMU combinedSimulationFMU = new FMU();
    private final FMU controllerFMU = new FMU();
    private final FMU winchFMU = new FMU();

    private void copyVariablesFromFMU(Simulation source, Map<String, Double> destination, String prefix) {

        destination.keySet().forEach((variableName) -> {
            SingleRead reader = source.read(prefix + variableName);
            double value = reader.asDouble();
            destination.put(variableName, value);
        });
    }

    @Before
    public void initialize() throws Exception {

        combinedSimulationFMU.load(FMULocations.COMBINED_FMU_PATH);
        winchFMU.load(FMULocations.WINCH_FMU_PATH);
        controllerFMU.load(FMULocations.CONTROLLER_FMU_PATH);

        initializeVariables();

        double stepSize = (double) 1 / FREQUENCY;
        double startTime = 0;

        combinedSimulationFMU.setStepSize(stepSize);
        combinedSimulationFMU.setStartTime(startTime);
        winchFMU.setStepSize(stepSize);
        winchFMU.setStartTime(startTime);
        controllerFMU.setStepSize(stepSize);
        controllerFMU.setStartTime(startTime);
    }

    private void initializeVariables() throws Exception {

        combinedSimulationFMU.prepare();

        copyVariablesFromFMU(combinedSimulationFMU.getSimulation(), winchFMU.getInputVariables(), "winch.");
        copyVariablesFromFMU(combinedSimulationFMU.getSimulation(), controllerFMU.getInputVariables(), "Controller.");
    }

    @Test
    public void perfomComparison() throws Exception {

        combinedSimulationFMU.prepare();
        winchFMU.prepare();
        controllerFMU.prepare();

        Simulation combinedSimulation = combinedSimulationFMU.getSimulation();
        Simulation winchSimulation = winchFMU.getSimulation();
        Simulation controllerSimulation = controllerFMU.getSimulation();

        SingleRead combinedVHeaveReader = VariableObtainer.getSingleRead(combinedSimulation, "Sine.vheave");
        WriteCall controllerVHeaveWriter = VariableObtainer.getWriteCall(controllerSimulation, "vheave");

        SingleRead winchVLoadReader = VariableObtainer.getSingleRead(winchSimulation, "vload");
        WriteCall controllerVLoadWriter = VariableObtainer.getWriteCall(controllerSimulation, "vload");

        SingleRead controllerDisplacementGainReader = VariableObtainer.getSingleRead(controllerSimulation, "displacementGain");
        WriteCall winchKWriter = VariableObtainer.getWriteCall(winchSimulation, "k");

        SingleRead combinedYLoadReader = VariableObtainer.getSingleRead(combinedSimulation, "winch.yload");

        SingleRead winchYLoadReader = VariableObtainer.getSingleRead(winchSimulation, "yload");

        int simulationSteps = (int) Math.ceil(FREQUENCY * DURATION);
        int stepsPerSample = simulationSteps / SAMPLES;
        if (stepsPerSample <= 0) {
            stepsPerSample = 1;
        }
        for (int stepIndex = 0; stepIndex <= simulationSteps; stepIndex++) {

            combinedSimulationFMU.doStep();

            winchFMU.doStep();

            double winch_vload = winchVLoadReader.asDouble();
            controllerVLoadWriter.with(winch_vload);

            double combined_vheave = combinedVHeaveReader.asDouble();
            controllerVHeaveWriter.with(combined_vheave);

            controllerFMU.doStep();

            double controller_displacementGain = controllerDisplacementGainReader.asDouble();
            winchKWriter.with(controller_displacementGain);

            if (stepIndex % stepsPerSample == 0) {

                double combined_time = combinedSimulation.getCurrentTime();
                double winch_time = winchSimulation.getCurrentTime();
                double controller_time = controllerSimulation.getCurrentTime();

                Assert.assertEquals(combined_time, winch_time, MAX_TIME_ERROR);
                Assert.assertEquals(combined_time, controller_time, MAX_TIME_ERROR);

                double combined_yload = combinedYLoadReader.asDouble();
                double winch_yload = winchYLoadReader.asDouble();
                Assert.assertEquals(combined_yload, winch_yload, MAX_ERROR);
            }
        }
    }
}
