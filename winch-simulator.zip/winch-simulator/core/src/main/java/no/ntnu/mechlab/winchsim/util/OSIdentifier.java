package no.ntnu.mechlab.winchsim.util;

public class OSIdentifier {

    public static OS identifyOS() {

        String osName = System.getProperty("os.name").toLowerCase();

        if (osName.contains("win")) {
            return OS.WINDOWS;
        }

        if (osName.contains("mac")) {
            return OS.MAC;
        }

        if (osName.contains("nix") || osName.contains("nux") || osName.contains("aix")) {
            return OS.UNIX;
        }

        if (osName.contains("sunos")) {
            return OS.SOLARIS;
        }

        return null;
    }

    public static enum OS {
        WINDOWS, UNIX, MAC, SOLARIS;
    }
}
