package no.ntnu.mechlab.winchsim.core;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.javafmi.wrapper.Simulation;
import org.javafmi.wrapper.variables.SingleRead;

public class WinchFMUTester {

    private static final String FMU_EXPECTED_OUTPUT_PATH = "binaries/model-test/yload.csv";
    private static final String FMU_PATH = "binaries/model-test/model.fmu";
    private static final double MAX_ERROR = 1.0 / 100.0;
    private static final double TARGET_END_TIME = 100;
    private static final double TARGET_FREQUENCY = 10000;

    private static final String TARGET_OUTPUT_VARIABLE_NAME = "stateVariables.yload";

    private final List<DataSample> actualSamples = new ArrayList<>();
    private final List<DataSample> expectedSamples = new ArrayList<>();

    private boolean approximates(double x, double y) {

        double error = x - y;
        return Math.abs(error) <= MAX_ERROR;
    }

    private void compare() {

        Iterator<DataSample> actualSamplesIterator = actualSamples.iterator();
        for (DataSample expectedSample : expectedSamples) {
            DataSample actualSample = actualSamplesIterator.next();

            if (!approximates(expectedSample.time, actualSample.time)) {
                System.out.println("time deviates. Expected: " + expectedSample.time + ". Actual: " + actualSample.time);
                break;
            }

            if (!approximates(expectedSample.yload, actualSample.yload)) {
                System.out.println("yload deviates. Expected: " + expectedSample.time + ". Actual: " + actualSample.time);
                break;
            }
        }
    }

    private void compute() throws Exception {

        Simulation simulation = new Simulation(FMU_PATH);
        SingleRead read = simulation.read(TARGET_OUTPUT_VARIABLE_NAME);

        double stepSize = 1.0 / TARGET_FREQUENCY;

        Iterator<DataSample> expectedSamplesIterator = expectedSamples.iterator();
        DataSample nextExpectedSample = expectedSamplesIterator.next();

        double t = 0;
        simulation.init(t);
        while (t < TARGET_END_TIME) {

            if (t >= nextExpectedSample.time) {

                System.out.println(read.asDouble());

                DataSample sample = new DataSample(t, 0, 0, read.asDouble());
                actualSamples.add(sample);

                nextExpectedSample = expectedSamplesIterator.next();
            }

            simulation.doStep(stepSize);
            t = simulation.getCurrentTime();
        }
    }

    private void loadExpectedData() throws Exception {

        File file = new File(FMU_EXPECTED_OUTPUT_PATH);
        try (Scanner scanner = new Scanner(file)) {

            // Discard the first line
            scanner.nextLine();

            while (scanner.hasNextLine()) {

                String line = scanner.nextLine();
                String[] lineSplit = line.split(",");
                double time = Double.parseDouble(lineSplit[0]);
                double yloadGlobal = Double.parseDouble(lineSplit[1]);
                double heave = Double.parseDouble(lineSplit[2]);
                double yload = Double.parseDouble(lineSplit[3]);

                DataSample sample = new DataSample(time, yloadGlobal, heave, yload);
                expectedSamples.add(sample);
            }
        }
    }

    public void performTest() throws Exception {

        loadExpectedData();
        compute();
        compare();
    }

    private static class DataSample {

        final double heave, time, yLoadGlobal, yload;

        public DataSample(double time, double yLoadGlobal, double heave, double yload) {

            this.time = time;
            this.yLoadGlobal = yLoadGlobal;
            this.heave = heave;
            this.yload = yload;
        }
    }

}
