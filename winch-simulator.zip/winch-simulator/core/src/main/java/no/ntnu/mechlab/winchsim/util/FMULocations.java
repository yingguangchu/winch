package no.ntnu.mechlab.winchsim.util;

import java.io.File;

public class FMULocations {

    private static final String COMBINED_FMU_NAME = "model.fmu";
    private static final String CONTROLLER_FMU_NAME = "controller.fmu";
    private static final String FMU_MODELS_DIRECTORY_PATH;
    public static final String FMU_ROOT_DIRECTORY_PATH = "../fmu", COMBINED_FMU_PATH, CONTROLLER_FMU_PATH, WINCH_FMU_PATH;
    private static final String WINCH_FMU_NAME = "winch.fmu";

    static {

        String osFolderName = null;

        OSIdentifier.OS operatingSystem = OSIdentifier.identifyOS();
        switch (operatingSystem) {

            case WINDOWS:
                osFolderName = "win64";
                break;

            case UNIX:
                osFolderName = "linux";
                break;

        }

        FMU_MODELS_DIRECTORY_PATH = FMU_ROOT_DIRECTORY_PATH + File.separator + osFolderName;
        System.out.println("FMU_MODELS_DIRECTORY_PATH = " + FMU_MODELS_DIRECTORY_PATH);

        COMBINED_FMU_PATH = FMU_MODELS_DIRECTORY_PATH + File.separator + COMBINED_FMU_NAME;
        System.out.println("COMBINED_FMU_PATH = " + COMBINED_FMU_PATH);

        CONTROLLER_FMU_PATH = FMU_MODELS_DIRECTORY_PATH + File.separator + CONTROLLER_FMU_NAME;
        System.out.println("CONTROLLER_FMU_PATH = " + CONTROLLER_FMU_PATH);

        WINCH_FMU_PATH = FMU_MODELS_DIRECTORY_PATH + File.separator + WINCH_FMU_NAME;
        System.out.println("WINCH_FMU_PATH = " + WINCH_FMU_PATH);
    }

    private FMULocations() {
    }
}
