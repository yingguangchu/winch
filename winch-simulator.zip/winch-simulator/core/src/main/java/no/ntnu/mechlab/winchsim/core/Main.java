package no.ntnu.mechlab.winchsim.core;

class Main {

    public static void main(String[] args) throws Exception {

        System.out.println("Hello world!");
    }
}
