package no.ntnu.mechlab.winchsim.fmuinfo;

public class FMUInfoException extends Exception {

    public FMUInfoException(String message) {
        super(message);
    }
}
