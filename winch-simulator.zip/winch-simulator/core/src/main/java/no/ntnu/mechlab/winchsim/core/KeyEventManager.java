package no.ntnu.mechlab.winchsim.core;

import java.awt.event.KeyEvent;

public class KeyEventManager implements java.awt.event.KeyListener {

    private final Provider<KeyEvent> keyPressEventProvider = new Provider<>();
    private final Provider<KeyEvent> keyReleaseEventProvider = new Provider<>();

    public Provider<KeyEvent> getKeyPressEventProvider() {
        return keyPressEventProvider;
    }

    public Provider<KeyEvent> getKeyReleaseEventProvider() {
        return keyReleaseEventProvider;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        keyPressEventProvider.provide(e);
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keyReleaseEventProvider.provide(e);
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
}
