package no.ntnu.mechlab.winchsim.util;

import org.javafmi.wrapper.Simulation;
import org.javafmi.wrapper.variables.SingleRead;

public class VariableObtainer {

    public static SingleRead getSingleRead(Simulation simulation, String variableName) throws Exception {

        SingleRead result;
        try {

            result = simulation.read(variableName);
        }
        catch (NullPointerException e) {

            throw new Exception("Output variable named \"" + variableName + "\" not found");
        }
        return result;
    }

    public static Simulation.WriteCall getWriteCall(Simulation simulation, String variableName) throws Exception {

        Simulation.WriteCall result;
        try {

            result = simulation.write(variableName);
        }
        catch (NullPointerException e) {

            throw new Exception("Inptut variable named \"" + variableName + "\" not found");
        }
        return result;
    }

    private VariableObtainer() {
    }
}
