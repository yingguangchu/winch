package no.ntnu.mechlab.winchsim.fmuinfo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FMUInfoReader {

    private final List<VariableEntry> variableEntries = new ArrayList<>();

    public VariableEntry[] getVariableEntries() {

        return variableEntries.toArray(new VariableEntry[variableEntries.size()]);
    }

    private void parseLine(String line) throws FMUInfoException {

        line = line.trim();

        if (line.length() == 0) {
            return;
        }

        if (line.charAt(0) == '#') {
            return;
        }

        String[] lineSplit = line.split(";");
        if (lineSplit.length < 4) {
            throw new FMUInfoException("Line does not have 4 or more, semicolon-separated values: " + line);
        }

        VariableEntry entry = new VariableEntry(lineSplit[0], lineSplit[1], lineSplit[2], lineSplit[3]);
        variableEntries.add(entry);
    }

    public void readVariables(File file) throws FileNotFoundException, FMUInfoException {

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                parseLine(scanner.nextLine());
            }
        }
    }

    public void readVariables(String fmuInfoPath) throws FileNotFoundException, FMUInfoException {

        File file = new File(fmuInfoPath);
        readVariables(file);
    }

    public static class VariableEntry {

        private final String name;
        private final String label;
        private final String defaultValue;
        private final String description;

        public VariableEntry(String name, String label, String defaultValue, String description) {
            this.name = name;
            this.label = label;
            this.defaultValue = defaultValue;
            this.description = description;
        }

        public String getName() {
            return name;
        }

        public String getLabel() {
            return label;
        }

        public String getDefaultValue() {
            return defaultValue;
        }

        public String getDescription() {
            return description;
        }
    }
}
