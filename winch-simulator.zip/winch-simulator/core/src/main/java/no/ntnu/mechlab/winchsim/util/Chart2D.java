package no.ntnu.mechlab.winchsim.util;

import java.awt.event.KeyEvent;
import java.util.Map;
import no.ntnu.mechlab.winchsim.core.KeyEventManager;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ui.ApplicationFrame;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Chart2D {

    public void addSeries(String label, Map<Double, Double> values) {

        XYSeries series = new XYSeries(label);
        values.forEach((x, y) -> {
            series.add(x, y);
        });
        seriesCollection.addSeries(series);
    }

    XYSeriesCollection seriesCollection = new XYSeriesCollection();

    private final Frame frame = new Frame();

    private final String yLabel;

    public Chart2D(String yLabel) {
        this.yLabel = yLabel;
    }

    public void display() {

        JFreeChart lineChart = ChartFactory.createXYLineChart(null, "time", yLabel, seriesCollection);

        ChartPanel chartPanel = new ChartPanel(lineChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(1280, 1024));
        frame.setContentPane(chartPanel);
        frame.pack();
        frame.setVisible(true);
    }

    private static class Frame extends ApplicationFrame {

        public Frame() {

            super("Chart");

            KeyEventManager keyManager = new KeyEventManager();
            keyManager.getKeyPressEventProvider().addConsumer((event) -> {
                if (event.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    System.exit(0);
                }
            });
            addKeyListener(keyManager);
        }
    }
}
