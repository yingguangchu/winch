package no.ntnu.mechlab.winchsim.core;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.javafmi.modeldescription.ModelDescription;
import org.javafmi.modeldescription.ScalarVariable;
import org.javafmi.wrapper.Simulation;
import org.javafmi.wrapper.Simulation.WriteCall;
import org.javafmi.wrapper.variables.SingleRead;

public class FMU {

    public static final double DEFAULT_START_TIME = 0.0;
    public static final double DEFAULT_STEP_SIZE = 1 / 1000.0;
    private final Map<String, Double> inputVariables = new HashMap<>();
    private final Map<String, Double> outputVariables = new HashMap<>();
    private String path;
    private Simulation simulation;
    private final Map<String, SingleRead> singleReads = new HashMap<>();
    private double startTime = DEFAULT_START_TIME;
    private double stepSize = DEFAULT_STEP_SIZE;
    private final Map<String, WriteCall> writeCalls = new HashMap<>();

    public void doStep() {

        simulation.doStep(stepSize);
    }

    public double getCurrentTime() {

        return simulation.getCurrentTime();
    }

    public Map<String, Double> getInputVariables() {

        return inputVariables;
    }

    public Map<String, Double> getOutputVariables() {

        return Collections.unmodifiableMap(outputVariables);
    }

    public Simulation getSimulation() {

        return simulation;
    }

    public Map<String, SingleRead> getSingleReads() {
        return singleReads;
    }

    public Map<String, WriteCall> getWriteCalls() {
        return writeCalls;
    }

    private void initializeInputVariables() {

        ModelDescription modelDescription = simulation.getModelDescription();
        for (ScalarVariable variable : modelDescription.getModelVariables()) {

            if (variable.getCausality().equals("input")) {

                inputVariables.put(variable.getName(), 0.0);
            }
            else if (variable.getCausality().equals("output")) {

                outputVariables.put(variable.getName(), null);
            }
        }
    }

    private void initializeVariables() {

        writeCalls.clear();
        singleReads.clear();

        for (ScalarVariable variable : simulation.getModelDescription().getModelVariables()) {

            String causality = variable.getCausality();
            if (causality.equals("input")) {

                String name = variable.getName();
                WriteCall writeCall = simulation.write(name);
                writeCalls.put(name, writeCall);
            }
            else if (causality.equals("output")) {

                String name = variable.getName();
                SingleRead singleRead = simulation.read(name);
                singleReads.put(name, singleRead);
            }
        }
    }

    public void load(String path) throws Exception {
        this.path = path;
        simulation = new Simulation(path);
        initializeInputVariables();
    }

    public void prepare() {

        simulation = new Simulation(path);
        initializeVariables();
        updateInputVariables();
        simulation.init(startTime);
        updateOutputVariables();
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setStartTime(double startTime) {

        this.startTime = startTime;
    }

    public void setStepSize(double stepSize) {

        this.stepSize = stepSize;
    }

    public void terminate() {

        simulation.terminate();
    }

    public void updateInputVariable(String name) {

        double value = inputVariables.get(name);
        WriteCall writeCall = writeCalls.get(name);
        writeCall.with(value);
    }

    public void updateInputVariables() {

        inputVariables.keySet().forEach((name) -> {
            updateInputVariable(name);
        });
    }

    public void updateOutputVariable(String name) {

        SingleRead read = singleReads.get(name);
        double value = read.asDouble();
        outputVariables.put(name, value);
    }

    public void updateOutputVariables() {

        outputVariables.keySet().forEach((name) -> {
            updateOutputVariable(name);
        });
    }
}
