package no.ntnu.mechlab.winchsim.util;

public class Logger {

    public static void log(Throwable throwable) {
        throwable.printStackTrace();
    }

    public static void log(String message) {

        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        String log = "";

        if (stackTraceElements.length >= 3) {
            log += stackTraceElements[2].getClassName() + ": ";
        }

        log += message;
        System.out.println(log);
    }

    private Logger() {
    }
}
