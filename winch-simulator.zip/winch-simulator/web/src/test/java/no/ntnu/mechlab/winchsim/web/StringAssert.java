package no.ntnu.mechlab.winchsim.web;

import org.junit.Assert;

public class StringAssert {

    private StringAssert() {
    }

    public static void assertEquals(String expected, String actual) {

        Assert.assertTrue("Expected: " + expected + ". Actual: " + actual, expected.equals(actual));
    }
}
