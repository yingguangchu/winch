package no.ntnu.mechlab.winchsim.web;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.junit.Assert;
import org.junit.Test;

public class WinchSimulationTest {

    private static boolean arrayContainsString(JsonArray array, String target) {

        for (JsonElement element : array) {
            if (element.getAsString().equals(target)) {
                return true;
            }
        }
        return false;
    }

    @Test
    public void testParameterAlternatives() {

        Simulation winchSimulation = new WinchSimulation();
        JsonObject alternatives = winchSimulation.getParameterAlternatives();

        Assert.assertTrue(alternatives.has("simulation"));
        JsonObject simulationParameterAlternatives = alternatives.get("simulation").getAsJsonObject();

        JsonArray alternativesArray = simulationParameterAlternatives.get("inputEquation").getAsJsonArray();

        for (InputEquation equation : InputEquation.values()) {
            Assert.assertTrue(arrayContainsString(alternativesArray, equation.toString()));
        }
    }
}
