package no.ntnu.mechlab.winchsim.web;

import org.junit.Test;

public class KeyWordEnumSerializerTest {

    private static enum DummyEnum {

        HELLO_WORLD;
    }

    @Test
    public void testFromCamelCase() {

        String target = "helloWorld";
        String expected = "HELLO_WORLD";
        DummyEnum actual = KeyWordEnumSerializer.fromCamelCase(DummyEnum.class, target);
        StringAssert.assertEquals(expected, actual.toString());
    }

    @Test
    public void testToCamelCase() {

        DummyEnum target = DummyEnum.HELLO_WORLD;
        String expected = "helloWorld";
        String actual = KeyWordEnumSerializer.toCamelCase(target);
        StringAssert.assertEquals(expected, actual);
    }
}
