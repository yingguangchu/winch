package no.ntnu.mechlab.winchsim.web;

public enum InputEquation {

    SINE, COSINE
}
