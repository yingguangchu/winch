package no.ntnu.mechlab.cwa.demo;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.function.Consumer;
import no.ntnu.mechlab.cwa.CWASession;

public class DemoCWASession extends CWASession {

    static enum DemoKeywords {

        HELLO_WORLD, RECEIVE_PERSON;
    }

    private final static Gson gson;

    static {

        gson = new Gson();
    }

    public DemoCWASession(Consumer<String> clientCommandMessageConsumer) {

        super(clientCommandMessageConsumer, gson);
    }

    @Override
    public void onClose() {

        System.out.println("Session closed...");
    }

    @Override
    public void onOpen() {

        System.out.println("Session opened");

        sendCommand(DemoKeywords.HELLO_WORLD);

        JsonObject personData = new JsonObject();
        personData.add("age", new JsonPrimitive(123));
        sendCommand(DemoKeywords.RECEIVE_PERSON, personData);
    }
}
