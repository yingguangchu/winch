package no.ntnu.mechlab.cwa;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import no.ntnu.mechlab.cwa.util.StringCaseConverter;

public abstract class CWASession {

    public static final String DEFAULT_DELIMITER = " ";

    private static String enumToString(Enum<?> e) {

        return StringCaseConverter.toCamelCase(e.toString());
    }

    private final Map<String, NiladicFunction> clientCommandCallbacks = new HashMap<>();
    private final Consumer<String> clientCommandMessageConsumer;
    private final Map<String, Consumer<String>> clientDataCommandConsumers = new HashMap<>();
    private final Gson gson;

    public CWASession(Consumer<String> clientCommandMessageConsumer, Gson gson) {

        this.clientCommandMessageConsumer = clientCommandMessageConsumer;
        this.gson = gson;
    }

    public <T> void addClientCommandCallback(Enum<?> e, Class<T> classOfT, Consumer<T> consumer) {

        String commandKeyword = enumToString(e);
        validateCommandKeyword(commandKeyword);
        clientDataCommandConsumers.put(commandKeyword, (string) -> {

            consumer.accept(gson.fromJson(string, classOfT));
        });
    }

    public void addClientCommandCallback(Enum<?> e, NiladicFunction callback) {

        String commandKeyword = enumToString(e);
        validateCommandKeyword(commandKeyword);
        clientCommandCallbacks.put(commandKeyword, callback);
    }

    public abstract void onClose();

    public abstract void onOpen();

    public void parseMessage(String message) {

        int delimiterIndex = message.indexOf(DEFAULT_DELIMITER);
        if (delimiterIndex == -1) {

            String keyword = message;
            NiladicFunction callback = clientCommandCallbacks.get(keyword);
            if (callback == null) {
                sendError(new ClientError("Unrecognized command: " + keyword));
            }
            else {
                callback.invoke();
            }
        }
        else {

            String keyword = message.substring(0, delimiterIndex);
            Consumer<String> stringConsumer = clientDataCommandConsumers.get(keyword);
            if (stringConsumer == null) {
                sendError(new ClientError("Unrecognized command: " + keyword + " (data)"));
            }
            else {
                String dataString = message.substring(delimiterIndex);
                stringConsumer.accept(dataString);
            }
        }
    }

    public void sendCommand(Enum<?> e, JsonObject data) {

        String command = enumToString(e);
        String message = command + DEFAULT_DELIMITER + data.toString();
        clientCommandMessageConsumer.accept(message);
    }

    public void sendCommand(Enum<?> e) {

        String command = enumToString(e);
        clientCommandMessageConsumer.accept(command);
    }

    public void sendError(Throwable throwable) {

        ClientError error = new ClientError(throwable.getMessage());
        sendError(error);
    }

    public void sendError(ClientError error) {

        JsonObject errorDataObject = gson.toJsonTree(error).getAsJsonObject();
        sendCommand(BuiltinServerKeywords.ERROR, errorDataObject);
    }

    private void validateCommandKeyword(String commandKeyword) {

        if (commandKeyword.contains(DEFAULT_DELIMITER)) {
            System.err.println("Command keyword \"" + commandKeyword + "\" should not be used, it contains the message delimiter \"" + DEFAULT_DELIMITER + "\"");
        }
    }

    public static enum BuiltinServerKeywords {

        ERROR;
    }
}
