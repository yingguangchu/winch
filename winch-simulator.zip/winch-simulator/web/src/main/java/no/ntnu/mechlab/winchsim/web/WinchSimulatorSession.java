package no.ntnu.mechlab.winchsim.web;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.function.Consumer;
import no.ntnu.mechlab.cwa.CWASession;
import no.ntnu.mechlab.winchsim.web.command.client.ClientCommandKeyWord;

public class WinchSimulatorSession extends CWASession implements ComputationManager {

    private static final Gson gson;

    static {

        gson = new Gson();
    }

    private boolean closed = false;
    private Simulation simulation;

    public WinchSimulatorSession(Consumer<String> stringConsumer) {

        super(stringConsumer, gson);

        System.out.println("Session opened");

        simulation = new WinchSimulation();
        try {
            simulation.initialize();
        }
        catch (Exception e) {
            handleError(e);
        }

        initializeCommands();
    }

    @Override
    public void handleComputationProgress(int percentage) {

        JsonObject data = new JsonObject();
        data.add("progress", new JsonPrimitive(percentage));
        sendCommand(ClientCommandKeyWord.RECEIVE_COMPUTATION_PROGRESS, data);
    }

    private void handleError(Throwable error) {

        error.printStackTrace();
        sendError(error);
    }

    private void initializeCommands() {

        addClientCommandCallback(ServerCommandKeyWord.SET_PARAMETERS, JsonObject.class, (object) -> {
            setParameters(object);
        });

        addClientCommandCallback(ServerCommandKeyWord.GET_COMPUTATION, () -> {
            sendComputation();
        });

        addClientCommandCallback(ServerCommandKeyWord.RESET_PARAMETERS, () -> {
            simulation.resetParameters();
            sendParameters();
        });
    }

    @Override
    public void onClose() {

        closed = true;
        System.out.println("Session closed");
    }

    @Override
    public void onOpen() {

        sendParameterLabels();
        sendParameterAlternatives();
        sendParameters();
    }

    private void sendComputation() {
        try {
            JsonObject data = simulation.getComputation(this);
            if (!closed) {
                sendCommand(ClientCommandKeyWord.RECEIVE_DATA, data);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
            handleError(exception);
        }
    }

    private void sendParameterAlternatives() {

        JsonObject parameterAlternatives = simulation.getParameterAlternatives();
        sendCommand(ClientCommandKeyWord.RECEIVE_PARAMETER_ALTERNATIVES, parameterAlternatives);
    }

    private void sendParameterLabels() {

        JsonObject parameterLabels = simulation.getParameterLabels();
        sendCommand(ClientCommandKeyWord.RECEIVE_PARAMETER_LABELS, parameterLabels);
    }

    private void sendParameters() {

        JsonObject parameters = simulation.getParameters();
        sendCommand(ClientCommandKeyWord.RECEIVE_PARAMETERS, parameters);
    }

    private void setParameters(JsonObject parameters) {

        try {
            simulation.setParameters(parameters);
        }
        catch (Exception exception) {
            handleError(exception);
        }
    }

    @Override
    public boolean shouldKeepComputing() {

        return !closed;
    }
}
