package no.ntnu.mechlab.winchsim.web;

import java.io.IOException;
import java.util.function.Consumer;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import no.ntnu.mechlab.cwa.CWASession;

@ServerEndpoint("/websocket")
public class WebSocket implements Consumer<String> {

    private CWASession cwaSession;
    private RemoteEndpoint.Basic clientEndpoint;

    @Override
    public void accept(String string) {

        try {
            clientEndpoint.sendText(string);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @OnClose
    public void onClose() {

        cwaSession.onClose();
    }

    @OnMessage
    public void onMessage(String message) {

        cwaSession.parseMessage(message);
    }

    @OnOpen
    public void onOpen(Session session) {
        clientEndpoint = session.getBasicRemote();
        cwaSession = new WinchSimulatorSession(this);
        cwaSession.onOpen();
    }
}
