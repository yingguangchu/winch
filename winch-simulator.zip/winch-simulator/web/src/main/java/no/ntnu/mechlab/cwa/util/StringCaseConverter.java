package no.ntnu.mechlab.cwa.util;

public class StringCaseConverter {

    public static String fromCamelCase(String string) {

        StringBuilder newStringBuilder = new StringBuilder(string.length());

        for (char character : string.toCharArray()) {
            if (Character.isUpperCase(character)) {
                newStringBuilder.append("_");
            }
            newStringBuilder.append(character);
        }

        return newStringBuilder.toString().toUpperCase();
    }

    public static String toCamelCase(String string) {

        String lowerCase = string.toLowerCase();
        StringBuilder newStringBuilder = new StringBuilder(lowerCase.length());

        boolean capitalizeNextCharacter = false;
        for (int i = 0; i < lowerCase.length(); i++) {

            char character = lowerCase.charAt(i);
            if (character == '_') {
                capitalizeNextCharacter = true;
            }
            else {
                String characterString = "" + character;
                if (capitalizeNextCharacter) {
                    characterString = characterString.toUpperCase();
                    capitalizeNextCharacter = false;
                }
                newStringBuilder.append(characterString);
            }
        }

        return newStringBuilder.toString();
    }
}
