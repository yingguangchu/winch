package no.ntnu.mechlab.winchsim.web;

import com.google.gson.JsonObject;

public interface Simulation {

    public JsonObject getComputation(ComputationManager manager) throws Exception;

    public JsonObject getParameterLabels();

    public JsonObject getParameterAlternatives();

    public JsonObject getParameters();

    public void initialize() throws Exception;

    public void setParameters(JsonObject parameters) throws Exception;

    public void resetParameters();
}
