package no.ntnu.mechlab.winchsim.web;

public interface ComputationManager {

    public void handleComputationProgress(int percentage);

    public boolean shouldKeepComputing();

}
