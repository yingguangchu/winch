package no.ntnu.mechlab.winchsim.web.command;

import com.google.gson.JsonObject;

public class Command {

    private final JsonObject data;
    private final String keyWord;

    public Command(String keyWord, JsonObject data) {
        this.keyWord = keyWord;
        this.data = data;
    }

    public Command(String keyWord) {
        this(keyWord, new JsonObject());
    }

    public JsonObject getData() {
        return data;
    }

    public String getKeyWord() {
        return keyWord;
    }
}
