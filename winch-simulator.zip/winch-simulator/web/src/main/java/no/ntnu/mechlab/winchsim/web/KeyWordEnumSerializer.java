package no.ntnu.mechlab.winchsim.web;

public class KeyWordEnumSerializer {

    public static <T extends Enum<T>> T fromCamelCase(Class<T> enumType,
            String keyWordString) {

        StringBuilder newStringBuilder = new StringBuilder(keyWordString.length());

        for (char character : keyWordString.toCharArray()) {
            if (isUpperCase(character)) {
                newStringBuilder.append("_");
            }
            newStringBuilder.append(character);
        }

        String newString = newStringBuilder.toString().toUpperCase();
        return Enum.valueOf(enumType, newString);
    }

    private static boolean isUpperCase(char character) {

        String string = "" + character;
        return (string.equals(string.toUpperCase()));
    }

    public static String toCamelCase(Enum keyWord) {

        String lowerCase = keyWord.toString().toLowerCase();
        StringBuilder newStringBuilder = new StringBuilder(lowerCase.length());

        boolean capitalizeNextCharacter = false;
        for (int i = 0; i < lowerCase.length(); i++) {

            char character = lowerCase.charAt(i);
            if (character == '_') {
                capitalizeNextCharacter = true;
            }
            else {
                String characterString = "" + character;
                if (capitalizeNextCharacter) {
                    characterString = characterString.toUpperCase();
                    capitalizeNextCharacter = false;
                }
                newStringBuilder.append(characterString);
            }
        }

        return newStringBuilder.toString();
    }
}
