package no.ntnu.mechlab.winchsim.web;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import no.ntnu.mechlab.cwa.json.JsonMerger;
import no.ntnu.mechlab.winchsim.core.FMU;
import no.ntnu.mechlab.winchsim.fmuinfo.FMUInfoReader;
import no.ntnu.mechlab.winchsim.util.FMULocations;
import org.javafmi.wrapper.Simulation.WriteCall;
import org.javafmi.wrapper.variables.SingleRead;

public class WinchSimulation implements Simulation {

    private static final String CONTROLLER_FMU_INFO_FILE_NAME = "controller.csv";
    private static final String CONTROLLER_FMU_INFO_FILE_PATH = FMULocations.FMU_ROOT_DIRECTORY_PATH + File.separator + CONTROLLER_FMU_INFO_FILE_NAME;
    private static final String CONTROLLER_INPUT_VARIABLE_NAME = "vheave";
    private static final int MIN_PROGRESS_UPDATE_TIMESTEP_MS = 100;
    private static final String WINCH_FMU_INFO_FILE_NAME = "winch.csv";
    private static final String WINCH_FMU_INFO_FILE_PATH = FMULocations.FMU_ROOT_DIRECTORY_PATH + File.separator + WINCH_FMU_INFO_FILE_NAME;
    private static final Map<String, String> feedbackVariables = new HashMap();
    private static final Map<String, String> feedforwardVariables = new HashMap();
    private static final Map<InputEquation, Function<Double, Double>> inputFunctions = new HashMap();

    static {

        feedforwardVariables.put("vload", "vload");
        feedbackVariables.put("displacementGain", "k");
        feedbackVariables.put("heave", "heave");

        inputFunctions.put(InputEquation.SINE, (t) -> {
            return Math.sin(t);
        });

        inputFunctions.put(InputEquation.COSINE, (t) -> {
            return Math.cos(t);
        });
    }

    private static void applyFMUSimulationInfo(String infoFilePath, JsonObject parameterLabels, Map<String, Double> parameters) throws Exception {

        FMUInfoReader infoReader = new FMUInfoReader();
        infoReader.readVariables(infoFilePath);

        for (FMUInfoReader.VariableEntry variableEntry : infoReader.getVariableEntries()) {

            String name = variableEntry.getName();
            Double value = Double.parseDouble(variableEntry.getDefaultValue());
            parameters.put(name, value);

            parameterLabels.add(name, new JsonPrimitive(variableEntry.getLabel()));
        }
    }

    private static void assertMappedVariableNamesExist(Map<String, String> variableMap, Set<String> outputVariableNames, Set<String> inputVariableNames) throws Exception {
        for (Entry<String, String> entry : variableMap.entrySet()) {

            String outputVariableName = entry.getKey();
            if (!outputVariableNames.contains(outputVariableName)) {
                throw new Exception("No output variable named \"" + outputVariableName + "\"");
            }

            String inputVariableName = entry.getValue();
            if (!inputVariableNames.contains(inputVariableName)) {
                throw new Exception("No input variable named \"" + inputVariableName + "\"");
            }
        }
    }

    private static void copyParameters(Map<String, Double> source, Map<String, Double> destination) {
        source.forEach((name, value) -> {
            destination.put(name, value);
        });
    }

    private static void randomizeMapValues(Map<String, Double> map) {
        map.entrySet().forEach((variable) -> {
            variable.setValue(Math.random());
        });
    }

    private static void updateSimulationInput(FMU simulation, JsonObject parameters) {

        Map<String, Double> simulationInputVariables = simulation.getInputVariables();
        Set<String> inputVariableNames = simulationInputVariables.keySet();
        inputVariableNames.forEach((name) -> {
            double parameterValue = parameters.get(name).getAsDouble();
            simulationInputVariables.put(name, parameterValue);
        });
    }

    private Configuration configuration = new Configuration();
    private final FMU controllerSimulation = new FMU();
    private final Map<String, Double> defaultControllerSimParameters = new HashMap<>();
    private final Map<String, Double> defaultWinchSimParameters = new HashMap<>();
    private final Gson gson = new Gson();
    private final FMU winchSimulation = new FMU();

    @Override
    public JsonObject getComputation(ComputationManager computationManager) throws Exception {

        // Set simulation parameters accordingly
        JsonObject controllerSimulationParameters = configuration.getControllerParameters();
        updateSimulationInput(controllerSimulation, controllerSimulationParameters);

        JsonObject winchSimulationParameters = configuration.getSimulationParameters();
        updateSimulationInput(winchSimulation, winchSimulationParameters);

        // Prepare simulation
        Configuration.SimulationConfiguration simConfig = configuration.getSimulation();
        double targetTime = simConfig.getTime();
        int simulationSteps = (int) Math.ceil(simConfig.getStepsPerSec() * targetTime);
        double stepSize = simConfig.getTime() / simulationSteps;

        int simulationSamples = (int) Math.ceil(30 * targetTime);

        int stepsPerSample;
        if (simulationSteps < simulationSamples) {
            stepsPerSample = 1;
        }
        else {
            stepsPerSample = simulationSteps / simulationSamples;
        }

        controllerSimulation.prepare();
        controllerSimulation.setStepSize(stepSize);

        winchSimulation.prepare();
        winchSimulation.setStepSize(stepSize);

        Function<Double, Double> inputFunction = inputFunctions.get(configuration.getSimulation().getInputEquation());

        Double amplitude = configuration.getSimulation().getAmplitude();
        Double periodTime = configuration.getSimulation().getPeriodTime();

        Map<String, SingleRead> winchSimulationReads = winchSimulation.getSingleReads();
        Map<String, WriteCall> winchSimulationWriteCalls = winchSimulation.getWriteCalls();

        Map<String, SingleRead> controllerSimulationReads = controllerSimulation.getSingleReads();
        Map<String, WriteCall> controllerSimulationWriteCalls = controllerSimulation.getWriteCalls();

        // Map winch output to controller input (feedforward)
        Map<SingleRead, WriteCall> feedforwardWriteCalls = new HashMap<>();
        feedforwardVariables.forEach((outputName, inputName) -> {

            SingleRead read = winchSimulationReads.get(outputName);
            WriteCall writeCall = controllerSimulationWriteCalls.get(inputName);
            feedforwardWriteCalls.put(read, writeCall);
        });

        // Map controller output to winch input (feedback)
        Map<SingleRead, WriteCall> feedbackWriteCalls = new HashMap<>();
        feedbackVariables.forEach((outputName, inputName) -> {

            SingleRead read = controllerSimulationReads.get(outputName);
            WriteCall writeCall = winchSimulationWriteCalls.get(inputName);
            feedbackWriteCalls.put(read, writeCall);
        });

        WriteCall controllerInputWriteCall = controllerSimulationWriteCalls.get(CONTROLLER_INPUT_VARIABLE_NAME);

        int progressInteger = 0;

        long progressUpdateSentTimestep = 0;

        // Run simulation steps
        JsonArray simulationResult = new JsonArray(simulationSteps);
        for (int simulationStep = 0; computationManager.shouldKeepComputing() && simulationStep < simulationSteps; simulationStep++) {

            winchSimulation.doStep();

            feedforwardWriteCalls.forEach((read, writeCall) -> {
                writeCall.with(read.asDouble());
            });

            Double winchSimulationTime = winchSimulation.getCurrentTime();
            Double controllerInputValue = inputFunction.apply(winchSimulationTime / periodTime * 2.0 * Math.PI - Math.PI / 2) * amplitude;

            controllerInputWriteCall.with(controllerInputValue);
            controllerSimulation.doStep();

            feedbackWriteCalls.forEach((read, writeCall) -> {
                writeCall.with(read.asDouble());
            });

            if (simulationStep == 0 || simulationStep % stepsPerSample == 0 || simulationStep == simulationSteps - 1) {

                double progress = (simulationStep + 1) / (double) simulationSteps * 100.0;
                int newProgressInteger = (int) progress;

                if (newProgressInteger != progressInteger) {
                    long newProgressUpdateSentTimestep = System.currentTimeMillis();
                    if (newProgressUpdateSentTimestep - progressUpdateSentTimestep >= MIN_PROGRESS_UPDATE_TIMESTEP_MS) {
                        progressInteger = newProgressInteger;
                        computationManager.handleComputationProgress(progressInteger);
                        progressUpdateSentTimestep = newProgressUpdateSentTimestep;
                    }
                }

                JsonObject simulationStepResult = new JsonObject();
                simulationStepResult.add("time", new JsonPrimitive(winchSimulation.getCurrentTime()));

                simulationStepResult.add(CONTROLLER_INPUT_VARIABLE_NAME, new JsonPrimitive(controllerInputValue));

                for (Map.Entry<String, Double> outputVariable : controllerSimulation.getOutputVariables().entrySet()) {
                    controllerSimulation.updateOutputVariable(outputVariable.getKey());
                    Double value = outputVariable.getValue();
                    if (value.isNaN()) {
                        throw new Exception("Simulation output variable is not a number");
                    }
                    simulationStepResult.add(outputVariable.getKey(), new JsonPrimitive(value));
                }

                for (Map.Entry<String, Double> outputVariable : winchSimulation.getOutputVariables().entrySet()) {
                    String outputVariableName = outputVariable.getKey();
                    winchSimulation.updateOutputVariable(outputVariable.getKey());
                    Double value = outputVariable.getValue();
                    if (value.isNaN()) {
                        throw new Exception("Simulation output variable \"" + outputVariableName + "\" is not a number");
                    }
                    simulationStepResult.add(outputVariable.getKey(), new JsonPrimitive(value));
                }

                simulationResult.add(simulationStepResult);
            }
        }

        JsonObject dataObject = new JsonObject();
        dataObject.add("data", simulationResult);
        return dataObject;
    }

    @Override
    public JsonObject getParameterAlternatives() {

        JsonObject configurationObject = new JsonObject();
        JsonObject simulation = new JsonObject();
        configurationObject.add("simulation", simulation);

        JsonArray equationAlternatives = new JsonArray();
        simulation.add("inputEquation", equationAlternatives);

        for (InputEquation equation : InputEquation.values()) {
            equationAlternatives.add(equation.toString());
        }

        return configurationObject;
    }

    @Override
    public JsonObject getParameterLabels() {

        JsonObject winchSimulationParameterLabels = new JsonObject();
        JsonObject controllerSimulationParameterLabels = new JsonObject();

        try {
            applyFMUSimulationInfo(WINCH_FMU_INFO_FILE_PATH, winchSimulationParameterLabels, winchSimulation.getInputVariables());
            applyFMUSimulationInfo(CONTROLLER_FMU_INFO_FILE_PATH, controllerSimulationParameterLabels, controllerSimulation.getInputVariables());
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        JsonObject parameterLabels = new JsonObject();
        parameterLabels.add("winchParameters", winchSimulationParameterLabels);
        parameterLabels.add("controllerParameters", controllerSimulationParameterLabels);
        return parameterLabels;
    }

    @Override
    public JsonObject getParameters() {
        return gson.toJsonTree(configuration).getAsJsonObject();
    }

    @Override
    public void initialize() throws Exception {

        System.out.println("Loading winch simulation FMU: " + FMULocations.WINCH_FMU_PATH);
        winchSimulation.load(FMULocations.WINCH_FMU_PATH);

        System.out.println("Loading controller simulation FMU: " + FMULocations.CONTROLLER_FMU_PATH);
        controllerSimulation.load(FMULocations.CONTROLLER_FMU_PATH);

        initializeSimulationParameters();

        // Verify that the feedforward variables exist in the FMUs
        try {
            assertMappedVariableNamesExist(feedforwardVariables, winchSimulation.getOutputVariables().keySet(), controllerSimulation.getInputVariables().keySet());
        }
        catch (Exception e) {
            throw new Exception("Feedforward variable names mismatch: " + e.getMessage());
        }

        // Verify that the feedback variables exist in the FMUs
        try {
            assertMappedVariableNamesExist(feedbackVariables, controllerSimulation.getOutputVariables().keySet(), winchSimulation.getInputVariables().keySet());
        }
        catch (Exception e) {
            throw new Exception("Feedback variable names mismatch: " + e.getMessage());
        }

        if (!controllerSimulation.getInputVariables().containsKey(CONTROLLER_INPUT_VARIABLE_NAME)) {
            throw new Exception("Controller does not contain a input variable named \"" + CONTROLLER_INPUT_VARIABLE_NAME + "\"");
        }
    }

    private void initializeSimulationParameters() throws Exception {

        JsonObject parameterLabelsMessageData = new JsonObject();

        JsonObject winchSimulationParameterLabels = new JsonObject();
        defaultWinchSimParameters.clear();
        applyFMUSimulationInfo(WINCH_FMU_INFO_FILE_PATH, winchSimulationParameterLabels, defaultWinchSimParameters);
        parameterLabelsMessageData.add("winchParameters", winchSimulationParameterLabels);

        JsonObject controllerSimulationParameterLabels = new JsonObject();
        defaultControllerSimParameters.clear();
        applyFMUSimulationInfo(CONTROLLER_FMU_INFO_FILE_PATH, controllerSimulationParameterLabels, defaultControllerSimParameters);
        parameterLabelsMessageData.add("controllerParameters", controllerSimulationParameterLabels);

        resetParameters();
    }

    @Override
    public void resetParameters() {

        configuration = new Configuration();

        Map<String, Double> winchSimulationInput = winchSimulation.getInputVariables();
        randomizeMapValues(winchSimulationInput);
        copyParameters(defaultWinchSimParameters, winchSimulationInput);

        JsonObject simulationParameters = configuration.getSimulationParameters();
        winchSimulationInput.forEach((name, value) -> {
            simulationParameters.add(name, new JsonPrimitive(value));
        });

        Map<String, Double> controllerSimulationInput = controllerSimulation.getInputVariables();
        randomizeMapValues(controllerSimulationInput);
        copyParameters(defaultControllerSimParameters, controllerSimulationInput);

        JsonObject controllerParameters = configuration.getControllerParameters();
        controllerSimulationInput.forEach((name, value) -> {
            controllerParameters.add(name, new JsonPrimitive(value));
        });
    }

    @Override
    public void setParameters(JsonObject newParameters) throws Exception {

        JsonObject parameters = getParameters();
        JsonMerger.applyModification(parameters, newParameters.getAsJsonObject());
        configuration = gson.fromJson(parameters, Configuration.class);
    }
}
