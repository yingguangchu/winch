package no.ntnu.mechlab.winchsim.web;

import com.google.gson.JsonObject;

public class Configuration {

    private final JsonObject controllerParameters = new JsonObject();
    private final SimulationConfiguration simulation = new SimulationConfiguration();
    private final JsonObject winchParameters = new JsonObject();

    public JsonObject getControllerParameters() {
        return controllerParameters;
    }

    public SimulationConfiguration getSimulation() {
        return simulation;
    }

    public JsonObject getSimulationParameters() {
        return winchParameters;
    }

    public static class SimulationConfiguration {

        private double amplitude = 0.8;
        private InputEquation inputEquation = InputEquation.SINE;
        private double periodTime = 12.0;
        private int stepsPerSec = 1000;
        private double time = 30.0;

        public double getAmplitude() {
            return amplitude;
        }

        public InputEquation getInputEquation() {
            return inputEquation;
        }

        public double getPeriodTime() {
            return periodTime;
        }

        public int getStepsPerSec() {
            return stepsPerSec;
        }

        public double getTime() {
            return time;
        }
    }
}
