package no.ntnu.mechlab.cwa;

public interface NiladicFunction {

    public void invoke();
}
