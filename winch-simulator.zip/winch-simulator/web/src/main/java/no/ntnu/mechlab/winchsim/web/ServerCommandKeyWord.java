package no.ntnu.mechlab.winchsim.web;

public enum ServerCommandKeyWord {

    SET_PARAMETERS, RESET_PARAMETERS, GET_COMPUTATION;
}
