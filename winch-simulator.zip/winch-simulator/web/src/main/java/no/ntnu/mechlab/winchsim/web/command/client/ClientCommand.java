package no.ntnu.mechlab.winchsim.web.command.client;

import com.google.gson.JsonObject;
import no.ntnu.mechlab.winchsim.web.KeyWordEnumSerializer;
import no.ntnu.mechlab.winchsim.web.command.Command;

public class ClientCommand extends Command {

    public ClientCommand(ClientCommandKeyWord keyWord, JsonObject data) {
        super(KeyWordEnumSerializer.toCamelCase(keyWord), data);
    }
}
