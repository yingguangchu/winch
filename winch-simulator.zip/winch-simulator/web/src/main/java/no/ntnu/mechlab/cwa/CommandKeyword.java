package no.ntnu.mechlab.cwa;

import no.ntnu.mechlab.cwa.util.StringCaseConverter;

public class CommandKeyword {

    public static CommandKeyword fromEnum(Enum<?> e) {

        return new CommandKeyword(StringCaseConverter.toCamelCase(e.toString()));
    }

    private final String string;

    private CommandKeyword(String string) {
        this.string = string;
    }

    public String getString() {
        return string;
    }

    @Override
    public String toString() {
        return getString();
    }
}
