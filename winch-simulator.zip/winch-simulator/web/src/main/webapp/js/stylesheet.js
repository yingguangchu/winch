class StyleSheet {

    constructor() {

        this.element = document.createElement("style");
        document.head.appendChild(this.element);
        this.element.appendChild(document.createTextNode(""));
    }

    insert(selector, rules) {

        let string = "";

        for (let attribute in rules) {
            let value = rules[attribute];
            string += attribute + ": " + value;
            if (typeof value == "number") {
                string += "px";
            }
            string += ";";
        }

        string = selector + "{" + string + "}";
        this.element.sheet.insertRule(string, 0);
    }
}

