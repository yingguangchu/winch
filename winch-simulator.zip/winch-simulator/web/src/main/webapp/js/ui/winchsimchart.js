
include("../lib/Chart.min.js");

class WinchSimulationChart {

    constructor(canvas) {

        let context = canvas.getContext("2d");
        this.chart = new Chart(context, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                        data: []
                    }]
            }
        });
    }

    setData(data) {
        this.chart.data = data;
        this.chart.update();
    }
}
