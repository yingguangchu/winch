function ParameterMenu(parentElement) {

    var SPLIT_SYMBOL = ".";
    var menu = this;

    function initStyle() {
        var stylesheetId = "menu_stylesheet";
        if (document.getElementById(stylesheetId) == null) {

            var style = document.createElement("style");
            style.id = stylesheetId;
            document.head.appendChild(style);
            style.appendChild(document.createTextNode(""));

            var sheet = style.sheet;

            function insert(str) {
                sheet.insertRule(str, 0);
            }

            // Style headers
            insert("div.pm {"
                    + "border-left: 2px solid black;"
                    + "padding: 5px;"
                    + "}");
            insert("p.pm-header {"
                    + "margin-bottom: 0px;"
                    + "margin-top: 0px;"
                    + "padding-top: 16px;"
                    + "font-weight: bold;"
                    + "}");
            insert("td.pm-label, td.pm-input {"
                    + "}");
            insert("td.pm-label {"
                    + "width: 100%;"
                    + "border-right: none;"
                    + "}");
            insert("td.pm-input {"
                    + "border-left: none;"
                    + "}");
            insert("input.pm {"
                    + "width: 120px;"
                    + "}");
            insert("input.pm[type='button'] {"
                    + "width: 60px;"
                    + "}");
            insert("table.pm {"
                    + "border-collapse: collapse;"
                    + "/*width:100%;*/"
                    + "}");
            insert("select.pm {"
                    + "width: 120px;"
                    + "}");
            insert("label.pm {"
                    + "margin-top: 10px;"
                    + "margin-bottom: 10px;"
                    + "font-weight: normal;"
                    + "}");
        }
    }
    initStyle();

    this.parentElement = parentElement;
    this.categoryDivs = [];

    function throwFunctionNotImplemented() {
        throw "Error: Function not implemented";
    }

    this.onInputChange = throwFunctionNotImplemented;
    this.onSave = throwFunctionNotImplemented;
    this.onLoad = throwFunctionNotImplemented;
    this.onDelete = throwFunctionNotImplemented;

    this.setSelectAlternatives = function(id, alternatives) {

        // Remove current alternatives
        var selectId = id + "-select";
        var selectElement = document.getElementById(selectId);
        if (!selectElement)
            throw "Could not find an element named " + selectId;

        while (selectElement.firstChild)
            selectElement.removeChild(selectElement.firstChild);

        var deleteElement = document.getElementById(id + "-delete");
        while (deleteElement.firstChild)
            deleteElement.removeChild(deleteElement.firstChild);

        // Add first (label) alternative
        selectElement.appendChild(document.createElement("option")).innerHTML = "Load";
        deleteElement.appendChild(document.createElement("option")).innerHTML = "Remove";

        // Add new alternatives
        for (var i = 0; i < alternatives.length; i++) {

            selectElement.appendChild(document.createElement("option")).innerHTML = alternatives[i];
            deleteElement.appendChild(document.createElement("option")).innerHTML = alternatives[i];
        }
    };

    this.addCategoryImportExport = function(id) {

        var categoryElement = document.getElementById(id + "-category");

        var saveButton = categoryElement.appendChild(document.createElement("input"));
        saveButton.classList.add("pm");
        saveButton.setAttribute("type", "button");
        saveButton.value = "Save";
        saveButton.setAttribute("pm-target", id);
        saveButton.onclick = function(evt) {
            menu.onSave(evt.target.getAttribute("pm-target"));
        };

        var loadSelector = categoryElement.appendChild(document.createElement("select"));
        loadSelector.classList.add("pm");
        loadSelector.setAttribute("id", id + "-select");
        loadSelector.setAttribute("pm-target", id);
        loadSelector.onchange = function(evt) {
            var src = evt.target;
            menu.onLoad(src.getAttribute("pm-target") + SPLIT_SYMBOL + src.value);
            src.value = "Load";
        };

        var deleteSelector = categoryElement.appendChild(document.createElement("select"));
        deleteSelector.classList.add("pm");
        deleteSelector.setAttribute("id", id + "-delete");
        deleteSelector.setAttribute("pm-target", id);
        deleteSelector.onchange = function(evt) {
            var src = evt.target;
            menu.onDelete(src.getAttribute("pm-target") + SPLIT_SYMBOL + src.value);
            src.value = "Remove";
        };
        categoryElement.appendChild(document.createElement("br"));
        categoryElement.appendChild(document.createElement("br"));

        menu.setSelectAlternatives(id, []);

    };

    this.addCategory = function(id, label) {

        var parent = this.parentElement;
        var idSplit = id.split(SPLIT_SYMBOL);
        var partialId = "";

        for (var idIndex = 0; idIndex < idSplit.length; idIndex++) {

            if (idIndex > 0)
                partialId += SPLIT_SYMBOL;
            partialId += idSplit[idIndex];

            // Create/obtain element
            var categoryElement = document.getElementById(partialId + "-category");
            if (categoryElement === null) {

                var categoryContainer = parent.appendChild(document.createElement("div"));
                var p = categoryContainer.appendChild(document.createElement("p"));
                p.setAttribute("id", partialId + "-header");
                p.innerHTML = (label != null ? label : idSplit[idIndex]);
                p.classList.add("pm-header");

                categoryElement = categoryContainer.appendChild(document.createElement("div"));
                categoryElement.setAttribute("id", partialId + "-category");
                categoryElement.classList.add("pm");
                this.categoryDivs.push(categoryElement);

            }

            parent = categoryElement;

        }

        return parent;

    };

    this.addParameterRow = function(id, label) {

        // Find/create category
        var idSplit = id.split(SPLIT_SYMBOL);
        idSplit.pop();
        var categoryId = idSplit.join(SPLIT_SYMBOL);
        if (categoryId === "")
            categoryId = "root";
        var categoryElement = document.getElementById(categoryId + "-category");
        if (categoryElement === null)
            categoryElement = this.addCategory(categoryId);

        var tableId = categoryId + "-table";

        var table = document.getElementById(tableId);
        if (table === null) {

            var child = categoryElement.firstChild;
            while (child !== null && child.tagName !== "DIV") {
                child = child.nextSibling;
            }

            table = categoryElement.insertBefore(document.createElement("table"), child);
            table.setAttribute("id", tableId);
            table.classList.add("pm");

        }

        var tr = table.appendChild(document.createElement("tr"));
        tr.classList.add("pm");
        var td1 = tr.appendChild(document.createElement("td"));
        td1.classList.add("pm-label");

        var labelElement = td1.appendChild(document.createElement("label"));
        labelElement.innerHTML += label;
        labelElement.setAttribute("for", id);
        labelElement.classList.add("pm");

        return tr;

    };

    this.addInput = function(id, label, value) {

        // Create/obtain element
        var element = document.getElementById(id);
        if (element === null) {
            var parameterRow = document.getElementById(id + "-row");
            if (parameterRow === null)
                parameterRow = this.addParameterRow(id, label);
            var td = parameterRow.appendChild(document.createElement("td"));
            td.classList.add("pm-input");
            element = td.appendChild(document.createElement("input"));
            element.setAttribute("id", id);
            element.setAttribute("pm-target", id);
            element.classList.add("pm");
            element.onchange = menu.onInputChange;
        }

        // Set element value
        element.value = value;
        if (typeof value === 'string')
            element.removeAttribute("type");
        else if (typeof value === 'boolean') {
            element.setAttribute("type", "checkbox");
            if (value)
                element.setAttribute("checked", "true");
        } else
            element.setAttribute("type", "number");

        return element;

    };

    this.addSelector = function(id, label, alternatives, value) {

        let element = document.getElementById(id);
        if (!element) {

            let parameterRow = document.getElementById(id + "-row");
            if (parameterRow === null)
                parameterRow = this.addParameterRow(id, label);

            let td = parameterRow.appendChild(document.createElement("td"));
            td.classList.add("pm-input");

            element = td.appendChild(document.createElement("select"));
            element.setAttribute("id", id);
            element.setAttribute("pm-target", id);
            element.classList.add("pm");
            element.onchange = menu.onInputChange;
        }

        while (element.hasChildNodes())
            element.removeChild(element.lastChild);

        for (let alternativeIndex in alternatives) {

            let option = element.appendChild(document.createElement("option"));
            let alternative = alternatives[alternativeIndex];
            option.innerHTML = alternative;
        }

        element.setAttribute("value", value);
    };

    this.getValue = function(id) {

        var element = document.getElementById(id);
        if (element)
            return element.value;
        else
            throw new Error("Could not find parameter \"" + id + "\"");

    };

    this.initializeToObject = function(object, parameterLabels, alternatives) {

        let self = this;

        if (!parameterLabels)
            parameterLabels = {};

        let attributeKeyArray = [];
        function recurse(object) {
            for (var attributeKey in object) {
                attributeKeyArray.push(attributeKey);
                let attributeValue = object[attributeKey];
                if (typeof object[attributeKey] == "object")
                    recurse(attributeValue);
                else {
                    let attributeKeyString = ("" + attributeKeyArray).replace(/,/, ".");

                    let label;
                    if (parameterLabels[attributeKeyString])
                        label = parameterLabels[attributeKeyString];
                    else
                        label = attributeKey;

                    if (alternatives && alternatives[attributeKeyString]) {

                        self.addSelector(attributeKeyString, label, alternatives[attributeKeyString], attributeValue);
                    } else {

                        let element = self.addInput(attributeKeyString, label, attributeValue);
                        element.setAttribute("step", "0.01");
                    }
                }
                attributeKeyArray.pop();
            }
        }
        recurse(object);
    };

}
