include("lib/three.min.js");
include("lib/OrbitControls.js");
include("lib/STLLoader.js");

let visualization = {
    container: null,
    renderer: null,
    camera: null,
    loadObject: null,
    winchObject: null,
    drumObject: null,
    simulationSteps: [],
    index: 0,
    constants: {
        DRUM_POS_Y_OFFSET: 10
    },
    drumModelRadius: 1.1
};

visualization.initialize = function(container) {

    this.container = container;

    const SETTINGS = {
        antialias: true
    };

    this.renderer = new THREE.WebGLRenderer(SETTINGS);
    this.camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);

    visualization.setSize(visualization.container.clientWidth, visualization.container.clientHeight);

    let scene = new THREE.Scene();
    scene.background = new THREE.Color(0xcccccc);
    container.appendChild(this.renderer.domElement);

    this.loadObject = new THREE.Object3D();
    this.drumObject = new THREE.Object3D();

    visualization.loadDrumModel();
    visualization.loadROVModel();

    scene.add(this.loadObject);
    scene.add(this.drumObject);

    this.camera.position.z = 10;
    this.camera.position.y = -5;
    this.camera.position.x = 2.5;
    this.camera.rotation.y = 3.14 / 8;

    let timestamp = new Date().getTime();
    let prevTimestamp = timestamp;

    let controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
    controls.enableKeys = false;

    function animate() {
        if (visualization.index < visualization.simulationSteps.length) {

            let simulationStep = visualization.simulationSteps[visualization.index];
            let targetDeltaT = simulationStep.time;

            timestamp = new Date().getTime();
            let deltaT = (timestamp - prevTimestamp) / 1000;
            if (deltaT >= targetDeltaT) {

                let object = visualization.loadObject;
                object.position.y = simulationStep.loadPosY - visualization.constants.DRUM_POS_Y_OFFSET;

                let drumObject = visualization.drumObject;
                drumObject.position.y = simulationStep.drumPosY;

                let rotation = -(simulationStep.drumPosY - simulationStep.loadPosY) / (2 * 3.14 * visualization.drumModelRadius);
                drumObject.rotation.z = rotation;

                visualization.index++;
            }
        } else {
            prevTimestamp = timestamp;
            visualization.index = 0;
        }

        controls.update();
        visualization.renderer.render(scene, visualization.camera);

        requestAnimationFrame(animate);
    }
    animate();
};

visualization.setSize = function(width, height) {
    this.renderer.setSize(width, height);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
};

visualization.processData = function(data) {

    this.simulationSteps = [];
    for (let i in data) {
        let sample = data[i];
        this.simulationSteps.push({
            time: sample.time,
            loadPosY: sample.yloadGlobal,
            drumPosY: sample.heave
        });
    }
};

visualization.loadDrumModel = function() {

    const DRUM_MODEL_RADIUS = 0.5;
    visualization.drumModelRadius = DRUM_MODEL_RADIUS;
    visualization.drumObject.position.x = -DRUM_MODEL_RADIUS;

    let wireframeMaterial = new THREE.MeshBasicMaterial({wireframe: true, color: 0x000000});
    let solidMaterial = new THREE.MeshBasicMaterial();

    let loader = new THREE.STLLoader();
    loader.load("models/DRUM_fixed.stl", (geometry) => {

        const DRUM_SCALE = 2.2;

        let drumMesh = new THREE.Mesh(geometry, solidMaterial);
        let drumMeshWF = new THREE.Mesh(geometry, wireframeMaterial);

        let drumModelObject = new THREE.Object3D();
        drumModelObject.scale.set(DRUM_SCALE, DRUM_SCALE, DRUM_SCALE);
        drumModelObject.rotation.y = Math.PI / 2;

        drumModelObject.add(drumMesh);
        drumModelObject.add(drumMeshWF);

        visualization.drumObject.add(drumModelObject);
    });
};

visualization.loadROVModel = function() {

    let wireframeMaterial = new THREE.MeshBasicMaterial({wireframe: true, color: 0x000000});
    let solidMaterial = new THREE.MeshBasicMaterial();

    let loader = new THREE.STLLoader();
    loader.load("models/ROV_fixed.stl", (geometry) => {

        const LOAD_SCALE = 2 / 10;

        let loadMesh = new THREE.Mesh(geometry, solidMaterial);
        let loadMeshWF = new THREE.Mesh(geometry, wireframeMaterial);

        let loadModelObject = new THREE.Object3D();
        loadModelObject.scale.set(LOAD_SCALE, LOAD_SCALE, LOAD_SCALE);
        loadModelObject.rotation.x = -Math.PI / 2;

        loadModelObject.add(loadMesh);
        loadModelObject.add(loadMeshWF);

        visualization.loadObject.add(loadModelObject);
    });
};
