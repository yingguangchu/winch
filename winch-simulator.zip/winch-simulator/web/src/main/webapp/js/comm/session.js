var SessionConstant = {// SESSION CONSTANTS
    Command: {

        GET_PARAMETERS: "getParameters",
        SET_PARAMETERS: "setParameters",
        RESET_PARAMETERS: "resetParameters",

        SAVE_PROPERTY: "saveProperty",
        LOAD_PROPERTY: "loadProperty",
        DELETE_PROPERTY: "deleteProperty",
        GET_PROPERTY_FILENAMES: "getPropertyFilenames",

        GET_COMPUTED_DATA: "getComputation"
    },
    Path: {
        WEBSOCKET: "websocket"
    },
    SPLIT_SYMBOL: " ",
    MessageArgument: {
        FILE_NAME: "fileName",
        NEW_DATA: "newData",
        PROPERTY_NAME: "propertyKey"
    }
};

function Session(client) {

    let webSocket;

    function getRequestWithFileName(fileName) {

        var result = {};
        result[SessionConstant.MessageArgument.FILE_NAME] = fileName;
        return result;
    }

    function parseMessage(string) {

        var splitIndex = string.indexOf(" ");
        var keyWord = splitIndex === -1 ? string : string.substring(0, splitIndex);
        var data = splitIndex === -1 ? null : JSON.parse(string.substring(splitIndex + 1));

        if (client[keyWord] == null) {
            throw "Function \"" + keyWord + "\" is undefined for the client. Please implement this function";
        } else
        if (data != null)
            client[keyWord](data);
        else
            client[keyWord]();
    }

    this.init = function (xmlRequestOverride) {
        queueUser(xmlRequestOverride);
    };

    this.saveProperty = function (id) {
        sendRequest(SessionConstant.Command.SAVE_PROPERTY, getRequestWithFileName(id));
    };

    this.loadProperty = function (id) {
        sendRequest(SessionConstant.Command.LOAD_PROPERTY, getRequestWithFileName(id));
    };

    this.deleteProperty = function (id) {
        sendRequest(SessionConstant.Command.DELETE_PROPERTY, getRequestWithFileName(id));
    };

    this.getComputedData = function () {
        sendRequest(SessionConstant.Command.GET_COMPUTED_DATA);
    };

    this.close = function () {
        webSocket.close();
    };

    this.setData = function (data) {
        sendRequest(SessionConstant.Command.SET_PARAMETERS, data);
    };

    this.initializeWebSocket = function (onOpen) {
        var wsURL = "";

        if (window.location.protocol === "https:")
            wsURL += "wss://";
        else
            wsURL += "ws://";

        wsURL += window.location.hostname;

        if (window.location.port !== "")
            wsURL += ":" + window.location.port;

        wsURL += window.location.pathname;
        wsURL += SessionConstant.Path.WEBSOCKET;

        webSocket = new WebSocket(wsURL);

        webSocket.onopen = function () {
            if (onOpen)
                onOpen();
        };

        webSocket.onmessage = function (data) {
            parseMessage(data.data);
        };

        webSocket.onclose = function () {
            client.sessionClosed();
        };
    };

    /**
     * @param {Command} command
     */
    this.sendCommand = function (command) {
        webSocket.send(command.toMessage());
    };
}

function Command(command) {

    if (command == undefined)
        throw "Error: Command key word is undefined";

    this.data = null;

    this.toMessage = function () {
        var string = command;
        if (this.data)
            string += SessionConstant.SPLIT_SYMBOL + JSON.stringify(this.data);
        return string;
    };
}
