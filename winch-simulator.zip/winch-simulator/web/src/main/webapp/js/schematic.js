let schematic = {
    canvas: document.createElement("canvas"),
    ctx: null,
    image: null,
    width: 0,
    height: 0,
    highlightedPart: null
};

schematic.initialize = function(container) {

    schematic.ctx = schematic.canvas.getContext("2d");

    container.appendChild(schematic.canvas);

    let image = new Image();
    image.src = "SecondaryControl.png";
    image.onload = function() {
        schematic.image = image;
        schematic.redraw();
    };
};

schematic.setSize = function(width, height) {

    // Preserve aspect ratio by constraining width/height when resizing

    let aspectRatio = width / height;
    if (aspectRatio > schematic.IMAGE_ASPECT_RATIO) {

        schematic.width = height * schematic.IMAGE_ASPECT_RATIO;
        schematic.height = height;
    } else {

        schematic.width = width;
        schematic.height = width / schematic.IMAGE_ASPECT_RATIO;
    }

    schematic.canvas.setAttribute("width", schematic.width);
    schematic.canvas.setAttribute("height", schematic.height);

    schematic.redraw();
};

schematic.redraw = function() {

    let ctx = schematic.ctx;
    ctx.clearRect(0, 0, schematic.canvas.width, schematic.canvas.height);

    if (!schematic.image)
        return;

    ctx.drawImage(schematic.image, 0, 0, schematic.width, schematic.height);

    /**
     * @param {schematic.Part} part
     */
    function drawPart(part) {

        let w = (part.x1 - part.x0) * schematic.width;
        let h = (part.y1 - part.y0) * schematic.height;

        ctx.beginPath();
        ctx.rect(
                part.x0 * schematic.width,
                part.y0 * schematic.height,
                w, h);
        ctx.strokeStyle = "#0000FF";
        ctx.stroke();

        ctx.fillStyle = "#0000FF";
        ctx.globalAlpha = 0.1;
        ctx.fill();
        ctx.globalAlpha = 1.0;
    }

    if (schematic.highlightedPart)
        drawPart(schematic.highlightedPart);
};

/**
 * @param {schematic.Part} attribute
 */
schematic.setHighlightedAttribute = function(attribute) {

    let part = schematic.outputAttributeParts[attribute];
    schematic.highlightedPart = part;
    schematic.redraw();
};

/**
 * @returns {schematic.Part}
 */
schematic.clearHighlightedAttribute = function() {

    schematic.highlightedPart = null;
    schematic.redraw();
};

/**
 * @param {schematic.Part} part
 */
schematic.onPartHovered = function(part) {

};

schematic.onNoPartHovered = function() {

};

schematic.IMAGE_WIDTH = 269;
schematic.IMAGE_HEIGHT = 294;
schematic.IMAGE_ASPECT_RATIO = schematic.IMAGE_WIDTH / schematic.IMAGE_HEIGHT;

schematic.Part = function(x0, y0, x1, y1) {

    this.x0 = x0;
    this.y0 = y0;
    this.x1 = x1;
    this.y1 = y1;
};

schematic.createPart = function(x0Pixel, y0Pixel, x1Pixel, y1Pixel) {

    return new schematic.Part(
            x0Pixel / schematic.IMAGE_WIDTH,
            y0Pixel / schematic.IMAGE_HEIGHT,
            x1Pixel / schematic.IMAGE_WIDTH,
            y1Pixel / schematic.IMAGE_HEIGHT);
};

schematic.parts = {

    1: schematic.createPart(33, 70, 68, 136),
    2: schematic.createPart(125, 6, 188, 60),
    3: schematic.createPart(191, 0, 257, 71),
    4: schematic.createPart(161, 58, 196, 121),
    5: schematic.createPart(1, 175, 52, 209),
    6: schematic.createPart(53, 181, 92, 219),
    7: schematic.createPart(80, 149, 132, 187),
    8: schematic.createPart(132, 148, 195, 188),
    9: schematic.createPart(217, 164, 266, 205),
    10: schematic.createPart(13, 230, 133, 294),
    11: schematic.createPart(224, 93, 260, 139)
};

schematic.outputAttributeParts = {

    heave: schematic.parts["3"],
    displacementGain: schematic.parts["2"],
    yload: schematic.parts["9"]
};

schematic.inputAttributeParts = {

};
