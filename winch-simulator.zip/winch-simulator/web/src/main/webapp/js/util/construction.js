
class SiteElement {

    constructor(type, parent) {
        this._element = document.createElement(type);
        if (parent)
            parent.appendChild(this._element);
    }

    set id(newID) {
        this._element.setAttribute("id", newID);
    }

    get id() {
        return this._element.getAttribute("id");
    }

    set element(newElement) {
        this.throwUnsupported();
    }

    get element() {
        return this._element;
    }

    throwUnsupported() {
        throw "Not supported";
    }
}

class SEInput extends SiteElement {

    constructor(type, parent) {

        super("input", parent);
        this.element.setAttribute("type", type);
    }
}

class SEButton extends SEInput {

    constructor(parent) {

        super("button", parent);
    }

    set label(newLabel) {
        this.element.setAttribute("value", newLabel);
    }

    get label() {
        this.element.getAttribute("value");
    }

    set callback(func) {
        this.element.addEventListener("click", func);
    }

    get callback() {
        this.throwUnsupported();
    }
}
