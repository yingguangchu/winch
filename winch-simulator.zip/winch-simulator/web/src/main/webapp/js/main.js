"use strict";

// Libraries
include("lib/jquery-3.2.1.min.js");
include("lib/bootstrap.min.js");
include("lib/FileSaver.min.js");

include("ui/parametermenu.js");
include("comm/session.js");
include("ui/winchsimchart.js");
include("stylesheet.js");
include("util/utility.js");
include("util/construction.js");
include("visualization.js");

include("schematic.js");

let winchsim = {
    session: null,
    parameterMenu: null,
    charts: {},
    chartContainer: null,
    parameterLabels: {},
    parameterAlternatives: {},
    viewContainer: null,
    fileSelectorElement: null,
    visualizationContainer: null,
    schematicContainer: null,
    uiSettingsMenu: null,
    uiSettings: {
        charts: {
            noOfSamples: 50
        }
    },
    computedData: [],
    computationTimer: null,
    infoHeaderElement: null
};


winchsim.triggerComputation = function() {
    let command = new Command(SessionConstant.Command.GET_COMPUTED_DATA);
    winchsim.session.sendCommand(command);
};


winchsim.importParameters = function() {

    if (!winchsim.fileSelectorElement) {
        winchsim.fileSelectorElement = document.createElement("input");
        winchsim.fileSelectorElement.setAttribute("type", "file");
        document.body.appendChild(winchsim.fileSelectorElement);
        winchsim.fileSelectorElement.setAttribute("style", "display:none;");
        winchsim.fileSelectorElement.addEventListener("change", function(evt) {

            let reader = new FileReader();
            reader.onload = function() {
                let newData = JSON.parse(reader.result);
                setParameterInputs(newData);
                putLocalParameters(newData);
            };
            reader.readAsText(evt.target.files[0]);
            winchsim.fileSelectorElement.value = "";
        });
    }

    winchsim.fileSelectorElement.click();
};


winchsim.exportParameters = function() {

    let localData = getLocalParameters();
    let localDataString = JSON.stringify(localData, null, 2);
    var blob = new Blob([localDataString], {type: "text/json;charset=utf-8"});
    saveAs(blob, "parameters.json");
};


winchsim.resetParameters = function() {

    let confirmation = confirm("Are you sure you wish to reset all the simulation parameters to their default values?");
    if (!confirmation)
        return;

    winchsim.putLocalParameters({});
    let command = new Command(SessionConstant.Command.RESET_PARAMETERS);
    winchsim.session.sendCommand(command);
};


winchsim.initializeLocalParameters = function() {
    if (!localStorage["winch-simulator-data"]) {
        winchsim.putLocalParameters({});
    }
};


winchsim.getLocalParameters = function() {

    let string = localStorage["winch-simulator-data"];
    let parameters = JSON.parse(string);

    // Convert all attribute values to numbers
    function makeAttributesNumbers(object) {
        for (var key in object) {
            let value = object[key];
            if (typeof object[key] == "object")
                makeAttributesNumbers(value);
            else
                object[key] = Number(value);
        }
    }
    makeAttributesNumbers(parameters);
    return parameters;
};


winchsim.putLocalParameters = function(object) {
    localStorage.setItem("winch-simulator-data", JSON.stringify(object));
};


winchsim.setParameter = function(id, value) {

    let command = new Command(SessionConstant.Command.SET_PARAMETERS);
    command.data = {};

    let data = command.data;

    let object = data;
    let idSplit = id.split(".");
    for (let i = 0; i < idSplit.length - 1; i++) {
        let idElement = idSplit[i];
        object[idElement] = {};
        object = object[idElement];
    }
    object[idSplit[idSplit.length - 1]] = value;
    winchsim.session.sendCommand(command);

    let localData = winchsim.getLocalParameters();
    for (let key in data)
        localData[key] = data[key];
    winchsim.putLocalParameters(localData);

    clearTimeout(winchsim.computationTimer);
    winchsim.computationTimer = setTimeout(function() {
        winchsim.triggerComputation();
    }, 200);
};


winchsim.onUISettingChange = function(evt) {

    let id = evt.target.id;
    if (id.includes("charts.target")) {
        let attribute = id.substr(id.lastIndexOf(".") + 1);
        let canvasContainer = document.getElementById(attribute + "-chartcontainer");
        if (evt.target.checked)
            canvasContainer.removeAttribute("hidden");
        else
            canvasContainer.setAttribute("hidden", true);
    }

    if (evt.target.id == "charts.noOfSamples") {
        winchsim.uiSettings.charts.noOfSamples = evt.target.value;
        winchsim.showComputedData();
    }
};


winchsim.initializeUI = function() {

    const SCROLLBAR_MARGIN = 20;
    const LEFT_CONTAINER_WIDTH = 340;
    const MINIMUM_WIDTH = 1200;
    const PADDING = 10;

    let bootstrapCSS = document.createElement("link");
    bootstrapCSS.setAttribute("rel", "stylesheet");
    bootstrapCSS.setAttribute("href", "css/bootstrap.min.css");
    document.head.appendChild(bootstrapCSS);

    let styleSheet = new StyleSheet();
    let leftX = 0, midX = LEFT_CONTAINER_WIDTH, rightX = 0;

    let leftDiv = document.createElement("div");
    leftDiv.classList.add("winchsim-container");
    leftDiv.style.setProperty("left", 0);
    leftDiv.style.setProperty("width", midX);
    document.body.appendChild(leftDiv);

    let midDiv = document.createElement("div");
    midDiv.classList.add("winchsim-container");
    midDiv.style.setProperty("left", midX);
    document.body.appendChild(midDiv);

    let rightTopDiv = document.createElement("div");
    rightTopDiv.classList.add("winchsim-container");
    document.body.appendChild(rightTopDiv);

    let rightBottomDiv = document.createElement("div");
    rightBottomDiv.classList.add("winchsim-container");
    document.body.appendChild(rightBottomDiv);

    styleSheet.insert("div.winchsim-container", {
        position: "absolute",
        padding: PADDING,
        top: 0,
        "overflow-y": "auto"
    });

    function createTabListElement(parent) {
        let element = document.createElement("ul");
        element.setAttribute("class", "nav nav-tabs");
        parent.appendChild(element);
        return element;
    }

    function createTabContentElement(container) {
        let element = document.createElement("div");
        element.setAttribute("class", "tab-content");
        container.appendChild(element);
        return element;
    }

    let tabListElement = null;
    let tabContentElement = null;

    let noOfTabs = 0;
    function createTabContainer(label, setActive) {

        let tabID = "tab" + noOfTabs;

        let listItem = document.createElement("li");
        if (setActive)
            listItem.setAttribute("class", "active");
        tabListElement.appendChild(listItem);

        let tabLink = document.createElement("a");
        tabLink.setAttribute("href", "#" + tabID);
        tabLink.setAttribute("data-toggle", "tab");
        tabLink.innerHTML = label;
        listItem.appendChild(tabLink);

        let container = document.createElement("div");
        container.setAttribute("id", tabID);

        if (setActive)
            container.setAttribute("class", "tab-pane active");
        else
            container.setAttribute("class", "tab-pane");

        tabContentElement.appendChild(container);

        noOfTabs++;

        return container;
    }

    function addContentLabel(label, container) {
        let labelElement = document.createElement("h4");
        labelElement.innerHTML = label;
        container.appendChild(labelElement);
    }

    tabListElement = createTabListElement(leftDiv);
    tabContentElement = createTabContentElement(leftDiv);

    let parametersContainer = createTabContainer("Parameters", true);
    addContentLabel("Simulation Parameters", parametersContainer);

    winchsim.parameterMenu = new ParameterMenu(parametersContainer);
    winchsim.parameterMenu.onInputChange = function(evt) {
        winchsim.setParameter(evt.target.id, evt.target.value);
    };

    let importButton = new SEButton(parametersContainer);
    importButton.label = "Import";
    importButton.callback = winchsim.importParameters;

    let exportButton = new SEButton(parametersContainer);
    exportButton.label = "Export";
    exportButton.callback = winchsim.exportParameters;

    let resetButton = new SEButton(parametersContainer);
    resetButton.label = "Reset";
    resetButton.callback = winchsim.resetParameters;

    winchsim.viewContainer = createTabContainer("View");
    addContentLabel("Data Graphs", winchsim.viewContainer);

    winchsim.uiSettingsMenu = new ParameterMenu(winchsim.viewContainer);
    winchsim.uiSettingsMenu.onInputChange = function(evt) {
        winchsim.onUISettingChange(evt);
    };
    winchsim.uiSettingsMenu.initializeToObject(winchsim.uiSettings);

    winchsim.chartContainer = midDiv;
    winchsim.visualizationContainer = rightTopDiv;

    visualization.initialize(winchsim.visualizationContainer);

    winchsim.schematicContainer = rightBottomDiv;
    schematic.initialize(winchsim.schematicContainer);

    let infoHeaderElement = document.createElement("h3");
    infoHeaderElement.style.setProperty("position", "absolute");
    infoHeaderElement.style.setProperty("background", "white");
    infoHeaderElement.innerHTML = "Loading ...";
    infoHeaderElement.style.setProperty("left", "20px");
    midDiv.appendChild(infoHeaderElement);

    winchsim.infoHeaderElement = infoHeaderElement;

    function resize() {

        let width = window.innerWidth;
        let height = window.innerHeight;
        if (width < MINIMUM_WIDTH) {
            width = MINIMUM_WIDTH;
            height -= SCROLLBAR_MARGIN;
        }

        let contentWidth = width - leftX - midX;
        rightX = midX + contentWidth / 2;

        midDiv.style.setProperty("width", rightX - midX);

        let rightWidth = width - rightX;
        rightTopDiv.style.setProperty("left", rightX);
        rightTopDiv.style.setProperty("width", width - rightX);

        rightBottomDiv.style.setProperty("left", rightX);
        rightBottomDiv.style.setProperty("width", width - rightX);
        rightBottomDiv.style.setProperty("top", height / 2);

        leftDiv.style.setProperty("height", height);
        midDiv.style.setProperty("height", height);

        rightTopDiv.style.setProperty("height", height / 2);
        rightBottomDiv.style.setProperty("height", height / 2);

        visualization.setSize(
                rightWidth - PADDING * 2,
                height / 2 - PADDING * 2
                );

        schematic.setSize(
                rightWidth - PADDING * 2,
                height / 2 - PADDING * 2
                );
    }
    let resizeTimeout;
    window.addEventListener("resize", function(evt) {
        window.clearTimeout(resizeTimeout);
        resizeTimeout = window.setTimeout(resize, 100);
    });

    resize();
};


winchsim.showComputedData = function() {

    let data = winchsim.computedData;

    let noOfDatasets = (Object.keys(data[0]).length - 1);
    // Create one chart per dataset
    // Iterate through variables of first datapoint, create one chart per variable
    for (let attribute in data[0]) {

        // Ignore variable "time"
        if (attribute == "time")
            continue;
        // If chart does not exist, create chart
        if (!winchsim.charts[attribute]) {

            let noOfCharts = Object.keys(winchsim.charts).length;
            let hue = noOfCharts / (noOfDatasets - 1);
            let rgb = utility.hsvToRgb(hue, 240 / 255, 1);
            let canvas = document.createElement("canvas");
            let canvasContainer = document.createElement("div");
            canvasContainer.setAttribute("id", attribute + "-chartcontainer");
            canvasContainer.appendChild(canvas);
            winchsim.chartContainer.appendChild(canvasContainer);
            let canvasContext = canvas.getContext("2d");
            let chart = new Chart(canvasContext, {
                type: "line",
                data: {
                    labels: [],
                    datasets: [{
                            fill: false,
                            label: attribute,
                            data: [],
                            borderColor: "rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + ",1)"
                        }]
                }
            });

            winchsim.uiSettingsMenu.addInput("charts.targets." + attribute, attribute, true);
            winchsim.charts[attribute] = chart;

            canvasContainer.addEventListener("mouseover", () => {
                schematic.setHighlightedAttribute(attribute);
            });

            canvasContainer.addEventListener("mouseout", () => {
                schematic.clearHighlightedAttribute();
            });
        }
    }

    let maxSamples = winchsim.uiSettings.charts.noOfSamples;

    let chartI = 0;
    // Iterate through charts
    for (let attribute in winchsim.charts) {
        let chart = winchsim.charts[attribute];
        // Reduce number of labels, if there are more than necesssary
        while (chart.data.labels.length > maxSamples)
            chart.data.labels.pop();
        // Reduce number of datapoints, if there are more than necesssary
        while (chart.data.datasets[0].data.length > maxSamples)
            chart.data.datasets[0].data.pop();
        chartI++;
    }

    let stepsPerSample;
    if (data.length <= maxSamples)
        stepsPerSample = 1;
    else
        stepsPerSample = Math.floor(data.length / maxSamples);

    for (let i = 0, i2 = 0; i < data.length; i++) {

        if (i != 0 && i != data.length - 1 && (i % stepsPerSample != 0))
            continue;

        let dataPoint = data[i];
        for (let chartI in winchsim.charts) {
            let chart = winchsim.charts[chartI];
            // Set label
            while (chart.data.labels.length <= i2)
                chart.data.labels.push("");
            let label = Math.round(dataPoint.time * 1000) / 1000;
            chart.data.labels[i2] = label;
            // Set chart data
            while (chart.data.datasets[0].data.length <= i2)
                chart.data.datasets[0].data.push(0);
            chart.data.datasets[0].data[i2] = dataPoint[chartI];
        }
        i2++;
    }

    for (let chartI in winchsim.charts) {
        let chart = winchsim.charts[chartI];
        chart.update();
    }
};

winchsim.setInfoHeader = function(text) {
    winchsim.infoHeaderElement.innerHTML = text;
};

winchsim.initialize = function() {

    window.loaded = true;
    document.body.innerHTML = "";

    winchsim.initializeUI();
    winchsim.initializeLocalParameters();

    let client = {
        receiveData: function(message) {
            winchsim.computedData = message.data;
            winchsim.showComputedData();
            visualization.processData(message.data);
            winchsim.setInfoHeader("");
        },
        receiveError: function(data) {
            winchsim.setInfoHeader("Server error: " + data.message);
        },
        receiveParameters: function(data) {

            // Receive external parameters
            winchsim.parameterMenu.initializeToObject(data, winchsim.parameterLabels, winchsim.parameterAlternatives);

            // Load local parameters
            let localData = winchsim.getLocalParameters();
            winchsim.parameterMenu.initializeToObject(localData);

            // Send local parameters
            let command = new Command(SessionConstant.Command.SET_PARAMETERS);
            command.data = localData;
            winchsim.session.sendCommand(command);

            // Trigger computation
            winchsim.triggerComputation();
        },
        receiveParameterLabels: function(data) {
            let attributeKeyArray = [];
            function recurse(object) {
                for (var attributeKey in object) {
                    attributeKeyArray.push(attributeKey);
                    let attributeValue = object[attributeKey];
                    if (typeof object[attributeKey] == "object")
                        recurse(attributeValue);
                    else {
                        let attributeKeyString = ("" + attributeKeyArray).replace(/,/, ".");
                        winchsim.parameterLabels[attributeKeyString] = attributeValue;
                    }
                    attributeKeyArray.pop();
                }
            }
            recurse(data);
        },
        receiveParameterAlternatives: function(data) {
            let attributeKeyArray = [];
            function recurse(object) {
                for (var attributeKey in object) {
                    attributeKeyArray.push(attributeKey);
                    let attributeValue = object[attributeKey];
                    if (Array.isArray(object[attributeKey]))
                    {
                        let attributeKeyString = ("" + attributeKeyArray).replace(/,/, ".");
                        winchsim.parameterAlternatives[attributeKeyString] = object[attributeKey];
                    } else
                    if (typeof object[attributeKey] == "object") {
                        recurse(attributeValue);
                    } else
                        throw "Expected variable to be object or array";
                    attributeKeyArray.pop();
                }
            }
            recurse(data);
        },
        receiveComputationProgress: function(data) {
            winchsim.setInfoHeader("Computation progress " + data.progress + "% ...");
        },
        sessionClosed: function() {
            winchsim.setInfoHeader("Connection closed: Server was stopped or restarted, please reload");
        }
    };
    winchsim.session = new Session(client);
    let onOpen = function() {
        console.log("WebSocket session open");
    };
    winchsim.session.initializeWebSocket(onOpen);
};


function main() {

    winchsim.initialize();
}
