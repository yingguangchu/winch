package no.uials.mechlab.tools.jscience.json;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.measure.unit.SI;
import javax.measure.unit.Unit;
import no.uials.mechlab.tools.jscience.SIProduct;
import org.junit.Assert;
import org.junit.Test;

public class UniqueSIUnitStringsTest {

    @Test
    public void testUniqueSIUnitStrings() {

        final List<Unit> units = new ArrayList<>();
        Consumer<Unit> addUnit = u -> {
            units.add(u);
        };

        final Method[] methods = SI.class.getDeclaredMethods();
        final AtomicBoolean erroneous = new AtomicBoolean(false);

        for (int i = -1; i < methods.length && erroneous.get(); i++) {
            Function<Unit, Unit> f;

            if (i >= 0) {
                final Method method = methods[i];
                f = unit1 -> {
                    try {
                        return (Unit) method.invoke(null, unit1);
                    }
                    catch (Exception ex) {
                        System.out.println("Failed method name: " + method.getName());
                    }
                    return null;
                };
            }
            else {
                f = unit1 -> {
                    return unit1;
                };
            }

            // Check SI product units
            for (Unit u : SIProduct.getInstance().getUnits()) {
                units.add(f.apply(u));
            }

            // Check SI units
            for (Unit u : SI.getInstance().getUnits()) {
                units.add(f.apply(u));
            }
        }

//        // Check non-SI units
//        units.addAll(NonSI.getInstance().getUnits());
        for (Unit target : units) {

            for (Unit unit : units) {
                if (unit == target) {
                    continue;
                }

                Assert.assertTrue(unit.toString().equals(target.toString()) == false);
            }
        }
    }
}
