package no.uials.mechlab.tools.jscience.json;

import com.google.gson.*;
import javax.measure.quantity.*;
import javax.measure.unit.*;
import no.uials.mechlab.tools.jscience.*;
import org.jscience.physics.amount.*;
import org.junit.*;

public class AmountSerializerTest {

    private Gson gson;

    @Before
    public void initialize() {

        GsonBuilder gb = new GsonBuilder();
        gb.registerTypeAdapter(Amount.class, new AmountSerializer(3));
        gson = gb.create();
    }

    @Test
    public void testDeserialization() {

        String string = "100.5 m^2";
        JsonElement json = new JsonPrimitive(string);
        Amount actual = gson.fromJson(json, Amount.class);
        Amount expected = Amount.valueOf(100.5, SI.SQUARE_METRE);

        Assert.assertTrue("Expected unit: " + expected.getUnit() + ". Actual unit: " + actual.getUnit(), actual.getUnit().equals(expected.getUnit()));
        Assert.assertTrue("Failed to deserialize " + string + ". Expected: " + expected + ". Actual: " + actual, expected.approximates(actual));
    }

    @Test
    public void testDeserialization2() {

        Amount<Volume> volume1 = Amount.valueOf(1001, SIProduct.CM3);

        Amount volume2 = gson.fromJson(new JsonPrimitive("1001 cm^3"), Amount.class);
        Assert.assertTrue(volume1.approximates(volume2));
    }

    @Test
    public void testSerialization() {

        Amount<Length> length = Amount.valueOf(15, SI.MILLIMETER);
        JsonElement jsonElement = gson.toJsonTree(length);

        String expectedString = "15.000" + AmountSerializer.SPLIT_SYMBOL + length.getUnit().toString();
        String actualString = jsonElement.getAsString();
        Assert.assertTrue("Expected: " + expectedString + "\tGot: " + actualString, (expectedString.equals(actualString)));
    }

    @Test
    public void testSerialization2() {

        Amount<Power> power1 = Amount.valueOf(157.000, SI.KILO(SI.WATT));
        String string1 = gson.toJson(power1);

        Amount power2 = gson.fromJson(string1, Amount.class);
        Assert.assertTrue(power1.approximates(power2));
    }
}
