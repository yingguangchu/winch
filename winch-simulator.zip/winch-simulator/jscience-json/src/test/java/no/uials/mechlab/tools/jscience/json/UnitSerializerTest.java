package no.uials.mechlab.tools.jscience.json;

import javax.measure.unit.SI;
import javax.measure.unit.Unit;
import static org.junit.Assert.*;
import org.junit.Test;

public class UnitSerializerTest {

    @Test
    public void testStringToUnit() {

        Unit expected = SI.CENTIMETRE.pow(3);
        String string = "cm^3";
        Unit actual = UnitSerializer.stringToUnit(string);
        assertTrue("Deserializing " + string + ". Expected: " + expected + ". Actual: " + actual, expected.equals(actual));
    }

    @Test
    public void testUnitToString() {

        String expected = "cm\u00B3";
        Unit unit = SI.CENTIMETER.pow(3);
        String actual = UnitSerializer.unitToString(unit);
        assertTrue("Serializing " + unit + ". Expected: " + expected + ". Actual: " + actual, expected.equals(actual));
    }
}
