package no.uials.mechlab.tools.storage;

import com.google.gson.*;
import java.util.Map.Entry;

public class JsonMerger {

    public static void applyModification(JsonElement base, JsonElement mod)
            throws MissingMemberException {

        if (base.isJsonObject() || base.isJsonArray()) {

            JsonObject modObject = mod.getAsJsonObject();

            for (Entry<String, JsonElement> entry : mod.getAsJsonObject().entrySet()) {

                String memberName = entry.getKey();
                JsonElement je = entry.getValue();

                // If base object is an array
                if (base.isJsonArray()) {
                    int i = Integer.parseInt(memberName);
                    if (base.getAsJsonArray().get(i).isJsonPrimitive()) {
                        base.getAsJsonArray().set(i, je);
                    }
                    else {
                        applyModification(base.getAsJsonArray().get(i), je);
                    }
                }
                // If new value is object
                else if (je.isJsonObject()) {
                    applyModification(base.getAsJsonObject().get(memberName), modObject.get(memberName));
                }
                // Assume new value is primitive
                else if (base.getAsJsonObject().has(memberName)) {
                    base.getAsJsonObject().add(memberName, je);
                }
                else {
                    throw new MissingMemberException(entry.getKey());
                }

            }

        }

    }

    private JsonMerger() {
    }

    @SuppressWarnings("serial")
    public static class MissingMemberException extends Exception {

        private final String memberName;

        public MissingMemberException(String memberName) {
            super("Could not modify object as it has no member named \"" + memberName + "\".");
            this.memberName = memberName;
        }

        public String getMemberName() {
            return memberName;
        }

    }

}
