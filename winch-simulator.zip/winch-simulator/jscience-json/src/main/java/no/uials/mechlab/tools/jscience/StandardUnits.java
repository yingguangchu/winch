package no.uials.mechlab.tools.jscience;

import javax.measure.quantity.*;
import javax.measure.unit.*;

public class StandardUnits {

    public static Unit[] getStandardUnits() {

        Unit[] units = {
            //
            // Jscience quantities
            //
            Acceleration.UNIT,
            AmountOfSubstance.UNIT,
            Angle.UNIT,
            AngularAcceleration.UNIT,
            AngularVelocity.UNIT,
            Area.UNIT,
            CatalyticActivity.UNIT,
            DataAmount.UNIT,
            DataRate.UNIT,
            Dimensionless.UNIT,
            Duration.UNIT,
            DynamicViscosity.UNIT,
            ElectricCapacitance.UNIT,
            ElectricCharge.UNIT,
            ElectricConductance.UNIT,
            ElectricCurrent.UNIT,
            ElectricInductance.UNIT,
            ElectricPotential.UNIT,
            ElectricResistance.UNIT,
            Energy.UNIT,
            Force.UNIT,
            Frequency.UNIT,
            Illuminance.UNIT,
            KinematicViscosity.UNIT,
            Length.UNIT,
            LuminousFlux.UNIT,
            LuminousIntensity.UNIT,
            MagneticFlux.UNIT,
            MagneticFluxDensity.UNIT,
            Mass.UNIT,
            MassFlowRate.UNIT,
            Power.UNIT,
            Pressure.UNIT,
            RadiationDoseAbsorbed.UNIT,
            RadiationDoseEffective.UNIT,
            RadioactiveActivity.UNIT,
            SolidAngle.UNIT,
            Temperature.UNIT,
            Torque.UNIT,
            Velocity.UNIT,
            Volume.UNIT,
            VolumetricDensity.UNIT,
            VolumetricFlowRate.UNIT,
            //
            // Custom quantities
            //
            MomentOfInertia.UNIT,
            YieldStrength.UNIT
        };

        return units;

    }

    private StandardUnits() {
    }

}
