package no.uials.mechlab.tools.jscience.json;

import com.google.gson.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;
import javax.measure.unit.*;
import no.uials.mechlab.tools.jscience.*;

public class UnitSerializer implements JsonDeserializer<Unit>, JsonSerializer<Unit> {

    public final static List<Unit> UNIT_COLLECTION;
    private static final String POWER_OF_SYMBOL = "\\^";

    static {

        List<Function<Unit, Unit>> prefixes = new ArrayList<>();
        prefixes.add(unit -> {
            return SI.NANO(unit);
        });
        prefixes.add(unit -> {
            return SI.MICRO(unit);
        });
        prefixes.add(unit -> {
            return SI.MILLI(unit);
        });
        prefixes.add(unit -> {
            return SI.CENTI(unit);
        });
        prefixes.add(unit -> {
            return SI.DECI(unit);
        });
        prefixes.add(unit -> {
            return SI.DEKA(unit);
        });
        prefixes.add(unit -> {
            return SI.HECTO(unit);
        });
        prefixes.add(unit -> {
            return SI.KILO(unit);
        });
        prefixes.add(unit -> {
            return SI.MEGA(unit);
        });
        prefixes.add(unit -> {
            return SI.GIGA(unit);
        });
        prefixes.add(unit -> {
            return SI.TERA(unit);
        });
        prefixes.add(unit -> {
            return SI.YOTTA(unit);
        });
        prefixes.add(unit -> {
            return SI.ATTO(unit);
        });
        prefixes.add(unit -> {
            return SI.PICO(unit);
        });
        prefixes.add(unit -> {
            return SI.ZETTA(unit);
        });
        prefixes.add(unit -> {
            return SI.EXA(unit);
        });
        prefixes.add(unit -> {
            return SI.FEMTO(unit);
        });
        prefixes.add(unit -> {
            return SI.ZEPTO(unit);
        });
        prefixes.add(unit -> {
            return SI.YOCTO(unit);
        });
        prefixes.add(unit -> {
            return SI.PETA(unit);
        });

        UNIT_COLLECTION = new ArrayList<>();

        // Add all SI product units
        UNIT_COLLECTION.addAll(SIProduct.getInstance().getUnits());

        // Add all SI units
        UNIT_COLLECTION.addAll(SI.getInstance().getUnits());

        BiConsumer<Function<Unit, Unit>, Unit> prefixingFunctionConsumer = (prefixer, unit) -> {
            Unit prefixedUnit = prefixer.apply(unit);
            String prefixedUnitString = prefixedUnit.toString();

            if (!prefixedUnitString.matches(".*[0-9].*")) {
                UNIT_COLLECTION.add(prefixedUnit);
            }
        };

        prefixes.forEach(prefix -> {

            // Add all prefixed SI product units
            SIProduct.getInstance().getUnits().forEach(u -> {
                prefixingFunctionConsumer.accept(prefix, u);
            });

            // Add all prefixed SI units
            SI.getInstance().getUnits().forEach(u -> {
                prefixingFunctionConsumer.accept(prefix, u);
            });
        });

        // Add all (the relentless) non-SI units
        UNIT_COLLECTION.addAll(NonSI.getInstance().getUnits());
    }

    public static Unit stringToUnit(String unitString) {

        Unit unit = null;

        int power = 1;
        String[] unitStringSplit = unitString.split(POWER_OF_SYMBOL);
        String unitStringShortened = unitStringSplit[0];
        if (unitStringSplit.length > 1) {
            power = Integer.parseInt(unitStringSplit[1]);
        }

        for (int i = 0; i < UNIT_COLLECTION.size() && unit == null; i++) {

            if (UNIT_COLLECTION.get(i).toString().equals(unitStringShortened)) {
                unit = UNIT_COLLECTION.get(i).pow(power);
                break;
            }
        }

        if (unit == null) {
            throw new JsonParseException("Could not parse " + unitString + " into a unit");
        }

        return unit;
    }

    public static String unitToString(Unit unit) {

        return unit.toString();
    }

    @Override
    public Unit deserialize(JsonElement je, Type type, JsonDeserializationContext jdc) throws JsonParseException {

        String unitString = je.getAsString();
        return stringToUnit(unitString);
    }

    @Override
    public JsonElement serialize(Unit t, Type type, JsonSerializationContext jsc) {

        return new JsonPrimitive(unitToString(t));
    }
}
