package no.uials.mechlab.tools.jscience.json;

import com.google.gson.*;
import java.lang.reflect.Type;
import java.util.Locale;

import javax.measure.unit.Unit;

import org.jscience.physics.amount.Amount;

@SuppressWarnings("rawtypes")
public class AmountSerializer implements JsonSerializer<Amount>, JsonDeserializer<Amount> {

    public final static Locale LOCALE = Locale.US;
    public final static String SPLIT_SYMBOL = " ";
    public final static String VALUE_PROPERTY = "val";

    public static boolean isParseable(JsonElement element) {
        return element.getAsString().split(SPLIT_SYMBOL).length == 2;
    }
    public final String formatString;

    public AmountSerializer(int precision) {

        this.formatString = "%." + precision + "f";
    }

    @Override
    public Amount deserialize(JsonElement source, Type type, JsonDeserializationContext context)
            throws JsonParseException {

        String[] split = source.getAsString().split(SPLIT_SYMBOL);
        if (split.length != 2) {
            throw new JsonParseException("Expected a number and a unit seperated by \"" + SPLIT_SYMBOL + "\", got " + source + ".");
        }

        double value = Double.parseDouble(split[0]);
        String unitString = split[1];

        Unit unit = UnitSerializer.stringToUnit(unitString);
        return Amount.valueOf(value, unit);
    }

    @Override
    public JsonElement serialize(Amount source, Type type, JsonSerializationContext context) {

        Unit unit = source.getUnit();
        @SuppressWarnings("unchecked")
        double value = source.doubleValue(unit);
        return new JsonPrimitive(String.format(LOCALE, formatString, value) + SPLIT_SYMBOL + UnitSerializer.unitToString(unit));
    }
}
