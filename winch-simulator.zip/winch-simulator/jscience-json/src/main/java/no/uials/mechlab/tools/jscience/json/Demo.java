package no.uials.mechlab.tools.jscience.json;

public class Demo {

    public static void main(String[] args) {

        String unitString = "cm^3";
    }
}
