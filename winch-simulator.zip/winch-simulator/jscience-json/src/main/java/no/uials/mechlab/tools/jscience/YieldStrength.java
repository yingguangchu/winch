package no.uials.mechlab.tools.jscience;

import javax.measure.quantity.*;
import javax.measure.unit.*;

public interface YieldStrength extends Quantity {

    public final static Unit<YieldStrength> UNIT = new ProductUnit<>(SI.NEWTON.divide(SI.MILLIMETER.pow(2)));

}
