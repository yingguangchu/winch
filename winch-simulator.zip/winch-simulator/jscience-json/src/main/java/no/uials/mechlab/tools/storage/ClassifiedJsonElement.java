package no.uials.mechlab.tools.storage;

import com.google.gson.*;

public class ClassifiedJsonElement {

    public final JsonElement data;
    public final Class<?> type;

    public ClassifiedJsonElement(Class<?> type, JsonElement data) {
        this.data = data;
        this.type = type;
    }
}
