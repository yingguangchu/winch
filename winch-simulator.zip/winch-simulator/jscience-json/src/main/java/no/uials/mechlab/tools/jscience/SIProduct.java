package no.uials.mechlab.tools.jscience;

import java.util.*;
import javax.measure.quantity.*;
import javax.measure.unit.*;

public class SIProduct extends SystemOfUnits {

    // cubic centimetre
    public final static Unit<Volume> CM3;

    private static final SIProduct INSTANCE;

    // kilogram square meters
    public final static Unit<MomentOfInertia> KGM2;

    // newtonmetre
    public final static Unit<Torque> NM;

    // newton/mm^2
    public final static Unit<YieldStrength> N_PER_MM2;

    // rad/s
    public final static Unit<AngularVelocity> RAD_PER_SEC;

    // revolutions/min
    public final static Unit<AngularVelocity> REV_PER_MIN;

    private static final HashSet<Unit<?>> UNITS;

    static {
        INSTANCE = new SIProduct();
        UNITS = new HashSet<>();

        CM3 = siProduct(SI.CENTIMETER.times(SI.CENTIMETER).times(SI.CENTIMETER).asType(Volume.class));
        KGM2 = siProduct(SI.KILOGRAM.times(SI.SQUARE_METRE).asType(MomentOfInertia.class));
        NM = siProduct(SI.NEWTON.times(SI.METER).asType(Torque.class));
        N_PER_MM2 = siProduct(SI.NEWTON.divide(SI.MILLIMETER.pow(2)).asType(YieldStrength.class));
        RAD_PER_SEC = siProduct(SI.RADIAN.divide(SI.SECOND).asType(AngularVelocity.class));
        REV_PER_MIN = siProduct(NonSI.REVOLUTION.divide(NonSI.MINUTE).asType(AngularVelocity.class));
    }

    public static SIProduct getInstance() {
        return INSTANCE;
    }

    private static <U extends Unit<?>> U siProduct(U unit) {
        UNITS.add(unit);
        return unit;
    }

    private SIProduct() {
    }

    @Override
    public Set<Unit<?>> getUnits() {
        return Collections.unmodifiableSet(UNITS);
    }
}
