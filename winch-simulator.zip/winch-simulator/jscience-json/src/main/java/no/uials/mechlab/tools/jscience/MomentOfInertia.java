package no.uials.mechlab.tools.jscience;

import javax.measure.quantity.Quantity;
import javax.measure.unit.ProductUnit;
import javax.measure.unit.SI;
import javax.measure.unit.Unit;

public interface MomentOfInertia extends Quantity {

    public final static Unit<MomentOfInertia> UNIT = new ProductUnit<MomentOfInertia>(
            SI.KILOGRAM.times(SI.SQUARE_METRE));

}
