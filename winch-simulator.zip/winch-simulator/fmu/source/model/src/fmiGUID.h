#define FMI_GUID "{dee07d5c-35e9-488b-870e-aaa3cd3bf0fc}"
