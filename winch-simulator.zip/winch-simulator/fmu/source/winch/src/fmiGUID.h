#define FMI_GUID "{affa05a4-f20e-4acc-9e6a-39b97f98560c}"
